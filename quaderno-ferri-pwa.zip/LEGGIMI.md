# Quaderno dei Ferri (PWA)

App statica: nessuna installazione, nessun build. Cartella da pubblicare = questa cartella.

File: index.html, style.css, script.js, manifest.json, service-worker.js, vercel.json, _headers, icons/

Aggiornamenti: carichi i file modificati su GitHub e l'host (Vercel/Netlify) pubblica da solo.
Il service worker scarica sempre l'ultima versione quando c'e' internet, quindi non devi
cambiare numeri di versione. Chi ha l'app aperta o installata la vede aggiornata al
successivo avvio (o entro pochi minuti, quando torna in primo piano).

I dati dei lavori e le foto restano sul dispositivo di chi usa l'app (non si sincronizzano tra dispositivi).
