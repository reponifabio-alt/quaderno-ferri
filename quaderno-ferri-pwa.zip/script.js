(function(){
"use strict";
var $=function(s,r){return (r||document).querySelector(s)};
var esc=function(s){return String(s==null?"":s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]})};
var sleep=function(ms){return new Promise(function(r){setTimeout(r,ms)})};
var view=$("#view");

var GRUPPI=[
  ["Capi",["Maglione","Cardigan","Gilet","Top e canotta","Vestito","Gonna","Pantaloni","Poncho e mantella"]],
  ["Accessori",["Sciarpa","Scialle","Stola","Scaldacollo","Cappello","Fascia per capelli","Guanti","Mezzeguanti","Muffole","Scaldamuscoli","Calze","Calzettoni","Pantofole","Borsa"]],
  ["Per la casa",["Coperta","Plaid","Copricuscino","Cestino","Presine","Strofinaccio"]],
  ["Neonati e bambini",["Copertina neonato","Tutina e body","Scarpine neonato","Cappellino neonato","Giacchino neonato","Peluche"]],
  ["Altro",["Fiori e decorazioni","Decorazioni natalizie","Altro"]]
];
var CATEGORIE=GRUPPI.reduce(function(a,g){return a.concat(g[1])},[]);
function catOptions(sel){
  return GRUPPI.map(function(g){
    return '<optgroup label="'+g[0]+'">'+g[1].map(function(c){return "<option"+(c===sel?" selected":"")+">"+c+"</option>"}).join("")+"</optgroup>";
  }).join("");
}
var STATI={incorso:"In corso",pausa:"In pausa",finito:"Finito"};
var UN={ferri:{s:"ferro",p:"ferri",S:"Ferro",P:"Ferri"},giri:{s:"giro",p:"giri",S:"Giro",P:"Giri"}};
var U=function(p){return UN[p.unita]||UN.ferri};

var projects=[],col=null,loaded=false,current={name:""},filter="tutti",loadTimer=null;
var armedDel=null,armT=null,hist=[];
var TRASH='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/></svg>';
var timers={},inflight={};
var LS="quaderno-ferri-v1";

function normN(o){
  ["riga","totale","rip","maglie","mlav"].forEach(function(k){var n=Number(o[k]);o[k]=isFinite(n)&&n>0?Math.floor(n):0});
  o.auto=!!o.auto;
  return o;
}
function norm(p){
  normN(p);
  if(!p.unita)p.unita="ferri";
  if(!p.stato)p.stato="incorso";
  if(!/^#[0-9a-fA-F]{6}$/.test(p.colore||""))p.colore="#E8688F";
  if(!p.cuci||typeof p.cuci!=="object"||Array.isArray(p.cuci))p.cuci={};
  p.foto=(Array.isArray(p.foto)?p.foto:[]).filter(function(f){return f&&typeof f.id==="string"&&f.id}).map(function(f){f.did=String(f.did||"");return f});
  p.copertina=typeof p.copertina==="string"?p.copertina:"";
  if(!Array.isArray(p.parti))p.parti=[];
  p.parti=p.parti.filter(function(t){return t&&typeof t==="object"}).map(function(t){
    normN(t);t.fatta=!!t.fatta;
    if(!t.id)t.id=newId();
    t.nome=String(t.nome||"Parte");
    t.istr=String(t.istr||"");
    return t;
  });
  return p;
}
function loadLocal(){try{var v=JSON.parse(localStorage.getItem(LS));return Array.isArray(v)?v.map(norm):[]}catch(e){return[]}}
function saveLocal(){try{localStorage.setItem(LS,JSON.stringify(projects))}catch(e){}}

var SYNC={load:"Carico i tuoi lavori…",local:"Salvato su questo dispositivo",saving:"Salvataggio…",ok:"Salvato sul tuo account",err:"Non riesco a salvare ora",slow:"Archivio non raggiungibile: mostro l'ultima copia"};
function setSync(k){var el=$("#sync");if(el)el.textContent=SYNC[k]||""}
var toastT=null;
function toast(msg){var t=$("#toast");t.textContent=msg;t.hidden=false;clearTimeout(toastT);toastT=setTimeout(function(){t.hidden=true},2400)}

function persist(p,delay){
  p.aggiornato=Date.now();saveLocal();
  if(!col){setSync("local");return}
  clearTimeout(timers[p.id]);
  timers[p.id]=setTimeout(function(){flush(p.id)},delay==null?450:delay);
}
async function flush(id){
  delete timers[id];
  var p=projects.find(function(x){return x.id===id});
  if(!p||!col)return;
  if(inflight[id]){timers[id]=setTimeout(function(){flush(id)},300);return}
  inflight[id]=true;setSync("saving");
  try{await col.doc(id).set(Object.assign({},p));setSync("ok")}catch(e){setSync("err")}
  finally{delete inflight[id]}
}
document.addEventListener("visibilitychange",function(){
  if(document.visibilityState==="hidden"){Object.keys(timers).forEach(function(id){clearTimeout(timers[id]);flush(id)})}
});

function onSnap(snap){
  var incoming=new Map();
  snap.docs.forEach(function(d){var data=d.data();if(data)incoming.set(d.id,data)});
  var next=[];
  incoming.forEach(function(data,id){
    var ex=projects.find(function(x){return x.id===id});
    if(ex){
      /* Stesso oggetto di prima: la scheda aperta continua a scrivere sul lavoro che viene mostrato. */
      if(!(timers[id]||inflight[id]))Object.assign(ex,data,{id:id});
      next.push(norm(ex));
    }else next.push(norm(Object.assign({},data,{id:id})));
  });
  projects.forEach(function(p){if(!incoming.has(p.id)&&(timers[p.id]||inflight[p.id]))next.push(p)});
  projects=next;saveLocal();loaded=true;
  if(!snap.metadata.fromCache){clearTimeout(loadTimer);setSync("ok")}
  onDataChange();
}
function onErr(){clearTimeout(loadTimer);setSync("err");loaded=true;onDataChange()}

function onDataChange(){
  if(current.name==="progetti")updateList();
  else if(current.name==="lavoro"){
    var p=projects.find(function(x){return x.id===current.id});
    if(!p)location.hash="progetti";else refreshCounter(p,false);
  }else if(current.name==="attesa")route();
}

function newId(){return "p"+Date.now().toString(36)+Math.random().toString(36).slice(2,6)}
function addProject(d){
  var p=Object.assign({id:newId(),nome:"",categoria:"Altro",filato:"",ferri:"",stato:"incorso",unita:"ferri",riga:0,totale:0,rip:0,maglie:0,mlav:0,auto:false,parti:[],cuci:{},foto:[],copertina:"",colore:"#E8688F",note:"",creato:Date.now(),aggiornato:Date.now()},d);
  projects.unshift(p);persist(p,0);return p;
}
async function removeProject(id){
  if(STANDALONE&&window.indexedDB){var rp=projects.find(function(x){return x.id===id});if(rp)(rp.foto||[]).forEach(function(f){localAssets["delete"](f.id).catch(function(){})})}
  clearTimeout(timers[id]);delete timers[id];
  projects=projects.filter(function(p){return p.id!==id});saveLocal();
  if(col){
    for(var i=0;i<30&&inflight[id];i++)await sleep(100);
    try{await col.doc(id).delete();setSync("ok")}catch(e){setSync("err")}
  }
  armedDel=null;
  toast("Lavoro eliminato");
  if(current.name==="progetti")updateList();else location.hash="progetti";
}

function ago(ts){
  var d=Math.floor((Date.now()-ts)/86400000);
  if(d<=0)return "oggi";if(d===1)return "ieri";if(d<30)return d+" giorni fa";
  return new Date(ts).toLocaleDateString("it-IT");
}
function pct(p){return p.totale>0?Math.min(100,Math.round(p.riga/p.totale*100)):0}
function seg(p){
  var on=0;
  if(p.totale>0){on=Math.min(24,Math.round(p.riga/p.totale*24));if(p.riga>0&&on===0)on=1}
  var h="";for(var i=0;i<24;i++)h+='<i class="'+(i<on?"on":"")+'"></i>';
  return '<div class="seg" aria-hidden="true">'+h+"</div>";
}
function toInt(v){var n=parseInt(String(v).replace(/\D/g,""),10);return isFinite(n)?Math.min(99999,n):0}
function segN(on){var h="";for(var i=0;i<24;i++)h+='<i class="'+(i<on?"on":"")+'"></i>';return '<div class="seg" aria-hidden="true">'+h+"</div>"}
function vib(){try{if(navigator.vibrate)navigator.vibrate(10)}catch(e){}}
function chg(p,fn){
  var t=T(p);
  hist.push({id:t.id,riga:t.riga,mlav:t.mlav,maglie:t.maglie});if(hist.length>40)hist.shift();
  fn(t);vib();refreshCounter(p,false);persist(p);
}
function stitchAdd(p,n){
  chg(p,function(t){
    for(var i=0;i<n;i++){
      if(t.maglie>0&&t.mlav>=t.maglie)break;
      t.mlav++;
      if(t.auto&&t.maglie>0&&t.mlav>=t.maglie){t.riga=Math.min(99999,t.riga+1);t.mlav=0}
    }
  });
}
function refreshStitches(p){
  if(!$("#sNum"))return;
  var u=U(p),done=p.maglie>0&&p.mlav>=p.maglie;
  $("#sLabel").textContent="Maglie del "+u.s;
  $("#sNum").textContent=p.mlav;
  $("#sOf").textContent=p.maglie>0?("su "+p.maglie+(done?" · "+u.s+" completo":" · ne mancano "+(p.maglie-p.mlav))):"Imposta le maglie sul "+u.s+" nella scheda per contare fino alla fine";
  var on=0;if(p.maglie>0){on=Math.min(24,Math.round(p.mlav/p.maglie*24));if(p.mlav>0&&on===0)on=1}
  $("#sProg").innerHTML=p.maglie>0?segN(on):"";
  $("#sDec").disabled=p.mlav<=0;
  $("#sInc").disabled=!p.auto&&done;
  $("#sInc5").disabled=!p.auto&&done;
  $("#sDone").textContent="Finito il "+u.s+": passa al prossimo";
  $("#sAuto").checked=!!p.auto;
  $("#sAutoTxt").textContent="Passa al "+u.s+" dopo l'ultima maglia";
  $("#sTot").textContent=p.maglie>0?"Sul "+u.s+" hai "+p.maglie+" maglie. Se aumenti o diminuisci, segnalo qui:":"";
}

/* ---------- Navigazione ---------- */
var wake=null,wakeOn=false;
async function acquireWake(){
  try{if(wakeOn&&navigator.wakeLock&&document.visibilityState==="visible"&&!wake){
    wake=await navigator.wakeLock.request("screen");wake.addEventListener("release",function(){wake=null});
  }}catch(e){wake=null}
}
function releaseWake(){wakeOn=false;try{if(wake)wake.release()}catch(e){}wake=null}
document.addEventListener("visibilitychange",acquireWake);

function route(){
  var h=location.hash.slice(1);
  releaseWake();
  var tab=h==="calcola"||h==="glossario"?h:"progetti";
  document.querySelectorAll(".tab").forEach(function(t){
    if(t.getAttribute("data-tab")===tab)t.setAttribute("aria-current","page");else t.removeAttribute("aria-current");
  });
  window.scrollTo(0,0);
  if(h.indexOf("lavoro-")===0){
    var id=h.slice(7),p=projects.find(function(x){return x.id===id});
    if(p)return showDetail(p);
    if(!loaded){current={name:"attesa"};view.innerHTML='<p class="hint">Carico il lavoro…</p>';return}
    location.replace("#progetti");return;
  }
  if(h==="calcola")return showCalc();
  if(h==="glossario")return showGlossary();
  showList();
}
window.addEventListener("hashchange",route);

/* ---------- Progetti proposti ---------- */
/* Ogni progetto è scritto in centimetri: maglie e ferri si ricalcolano dal campione di chi lo lavora. */
function tplHelpers(g){
  var mg=g.mg,fg=g.fg;
  return {
    mg:mg,fg:fg,
    st:function(cm,m){m=m||1;return Math.max(m,Math.round(cm*mg/10/m)*m)},
    rw:function(cm){return Math.max(1,Math.round(cm*fg/10))},
    cm:function(rows){return Math.round(rows/fg*100)/10}
  };
}
function PT(nome,tot,mag,rip,istr){return {nome:nome,totale:tot,maglie:mag,rip:rip||0,istr:istr}}
var TPL={};
function addTpl(cats,t){cats.forEach(function(c){(TPL[c]=TPL[c]||[]).push(t)})}
function rowsTxt(h,cm){return cm+" cm, circa "+h.rw(cm)+" ferri"}

addTpl(["Sciarpa"],{id:"sciarpa-coste",nome:"Sciarpa a coste 2/2",desc:"Elastica, non si arriccia sui bordi. Adatta a chi inizia.",liv:"Facile",tempo:"8-12 ore",filato:"Lana o misto lana di spessore medio",ferri:"5",unita:"ferri",
  params:[{k:"w",l:"Larghezza (cm)",v:22},{k:"l",l:"Lunghezza (cm)",v:170}],
  build:function(v,h){
    var n=Math.max(1,Math.round((v.w*h.mg/10-2)/4))*4+2,rows=h.rw(v.l);
    return {parti:[PT("Sciarpa",rows,n,2,"Avvia "+n+" maglie.\nFerro 1 (diritto): 2 dir., *2 rov., 2 dir.*; ripeti da * a * fino alla fine.\nFerro 2 (rovescio): 2 rov., *2 dir., 2 rov.*; ripeti da * a * fino alla fine.\nRipeti questi due ferri fino a "+rowsTxt(h,v.l)+".\nChiudi tutte le maglie come si presentano. Nascondi i fili.")],
      note:"Il numero di maglie è un multiplo di 4 più 2, così le coste tornano uguali ai due lati."};
  }});
addTpl(["Sciarpa"],{id:"sciarpa-legaccio",nome:"Sciarpa a legaccio",desc:"Tutti i ferri a diritto. Morbida e calda, per principianti.",liv:"Facile",tempo:"6-10 ore",filato:"Lana morbida di spessore medio",ferri:"5",unita:"ferri",
  params:[{k:"w",l:"Larghezza (cm)",v:18},{k:"l",l:"Lunghezza (cm)",v:150}],
  build:function(v,h){
    var n=h.st(v.w),rows=h.rw(v.l);
    return {parti:[PT("Sciarpa",rows,n,0,"Avvia "+n+" maglie.\nLavora tutti i ferri a diritto fino a "+rowsTxt(h,v.l)+".\nChiudi tutte le maglie a diritto. Nascondi i fili.")],
      note:"Segna con un segnapunti il lato diritto del lavoro per non perdere il conto dei ferri."};
  }});

var CAPPELLO_B=function(v,h,pompon){
  var n=h.st(v.circ-v.ease,8),s=n/8,cimaR=Math.max(2,2*(s-1)),bordoR=h.rw(v.bordo),corpoR=Math.max(1,h.rw(v.alt)-bordoR-cimaR);
  return {parti:[
    PT("Bordo",bordoR,n,4,"Avvia "+n+" maglie su ferri circolari (o 4 ferri a doppia punta). Chiudi a cerchio senza torcere le maglie e segna l'inizio del giro.\nGiri di coste: *2 dir., 2 rov.*, ripeti fino alla fine del giro.\nContinua per "+rowsTxt(h,v.bordo).replace("ferri","giri")+"."),
    PT("Corpo",corpoR,n,0,"Passa alla maglia rasata: tutti i giri a diritto.\nLavora fino a "+corpoR+" giri, cioè circa "+h.cm(corpoR)+" cm dopo il bordo."),
    PT("Cima",cimaR,n,0,"Dividi le maglie in 8 settori da "+s+" maglie.\nGiro con diminuzioni: *"+Math.max(0,s-2)+" dir., 2 insieme*, ripeti 8 volte.\nGiro successivo: tutto a diritto.\nOgni giro con diminuzioni lascia una maglia in meno per settore: *"+Math.max(0,s-3)+" dir., 2 insieme*, poi *"+Math.max(0,s-4)+" dir., 2 insieme*, e così via.\nQuando restano 8 maglie, taglia il filo lasciando 20 cm, passalo nelle 8 maglie e stringi. Fissa e nascondi il filo.")
  ],note:pompon?"Se vuoi il pompon, fissalo sulla cima con il filo rimasto.":""};
};
var CAPPELLO_S={labels:["Bimbo","S","M","L","XL"],def:"M",vals:{"Bimbo":{circ:50,alt:18},"S":{circ:54,alt:20},"M":{circ:56,alt:21},"L":{circ:58,alt:22},"XL":{circ:60,alt:23}}};
addTpl(["Cappello"],{id:"cappello-tondo",nome:"Cappello in tondo con bordo a coste",desc:"Bordo a coste 2/2, corpo in rasato e cima a otto spicchi.",liv:"Facile",tempo:"6-10 ore",filato:"Lana o misto lana di spessore medio",ferri:"4",unita:"giri",
  params:[{k:"circ",l:"Circonferenza della testa (cm)",v:56},{k:"ease",l:"Più stretto della testa di (cm)",v:2},{k:"alt",l:"Altezza totale (cm)",v:21},{k:"bordo",l:"Altezza del bordo (cm)",v:5}],
  taglie:CAPPELLO_S,build:function(v,h){return CAPPELLO_B(v,h,true)}});
addTpl(["Cappellino neonato"],{id:"cappellino-neonato",nome:"Cappellino neonato in tondo",desc:"Piccolo e morbido, con bordo a coste. Si lavora in fretta.",liv:"Facile",tempo:"3-4 ore",filato:"Lana o cotone morbido per neonati",ferri:"3.5",unita:"giri",
  params:[{k:"circ",l:"Circonferenza della testa (cm)",v:38},{k:"ease",l:"Più stretto della testa di (cm)",v:2},{k:"alt",l:"Altezza totale (cm)",v:14},{k:"bordo",l:"Altezza del bordo (cm)",v:3}],
  taglie:{labels:["0-3 mesi","3-6 mesi","6-12 mesi"],def:"0-3 mesi",vals:{"0-3 mesi":{circ:38,alt:14},"3-6 mesi":{circ:41,alt:15},"6-12 mesi":{circ:45,alt:16}}},
  build:function(v,h){return CAPPELLO_B(v,h,false)}});

addTpl(["Scaldacollo"],{id:"scaldacollo-coste",nome:"Scaldacollo a coste 2/2",desc:"Un anello lavorato in tondo, senza cuciture.",liv:"Facile",tempo:"5-8 ore",filato:"Lana morbida di spessore medio",ferri:"5",unita:"giri",
  params:[{k:"circ",l:"Circonferenza (cm)",v:62},{k:"alt",l:"Altezza (cm)",v:26}],
  build:function(v,h){
    var n=h.st(v.circ,4),rows=h.rw(v.alt);
    return {parti:[PT("Scaldacollo",rows,n,4,"Avvia "+n+" maglie su ferri circolari. Chiudi a cerchio senza torcere e segna l'inizio del giro.\nGiri: *2 dir., 2 rov.*, ripeti fino alla fine del giro.\nContinua per "+rows+" giri, circa "+v.alt+" cm.\nChiudi tutte le maglie come si presentano. Nascondi i fili.")],note:""};
  }});
addTpl(["Fascia per capelli"],{id:"fascia-coste",nome:"Fascia per capelli a coste",desc:"Fascia elastica da chiudere ad anello.",liv:"Facile",tempo:"2-3 ore",filato:"Lana morbida o cotone elastico",ferri:"4",unita:"ferri",
  params:[{k:"circ",l:"Circonferenza della testa (cm)",v:56},{k:"ease",l:"Più stretta della testa di (cm)",v:4},{k:"w",l:"Larghezza (cm)",v:9}],
  build:function(v,h){
    var n=Math.max(1,Math.round((v.w*h.mg/10-2)/4))*4+2,len=v.circ-v.ease,rows=h.rw(len);
    return {parti:[PT("Fascia",rows,n,2,"Avvia "+n+" maglie.\nFerro 1: 2 dir., *2 rov., 2 dir.*, ripeti fino alla fine.\nFerro 2: 2 rov., *2 dir., 2 rov.*, ripeti fino alla fine.\nRipeti questi due ferri fino a "+rowsTxt(h,len)+".\nChiudi le maglie come si presentano, poi cuci le due estremità tra loro per formare l'anello.")],note:""};
  }});
addTpl(["Stola"],{id:"stola-legaccio",nome:"Stola a legaccio con frange",desc:"Rettangolo morbido, con frange sulle due estremità.",liv:"Facile",tempo:"10-14 ore",filato:"Lana o mohair, spessore medio",ferri:"6",unita:"ferri",
  params:[{k:"w",l:"Larghezza (cm)",v:40},{k:"l",l:"Lunghezza (cm)",v:170}],
  build:function(v,h){
    var n=h.st(v.w),rows=h.rw(v.l);
    return {parti:[PT("Stola",rows,n,0,"Avvia "+n+" maglie con ferri circolari: lavori comunque avanti e indietro.\nTutti i ferri a diritto fino a "+rowsTxt(h,v.l)+".\nChiudi tutte le maglie.")],
      note:"Frange: taglia fili lunghi 30 cm, piegali a metà e annodali a gruppi di 3 sul bordo corto, uno ogni 1,5 cm."};
  }});

var COP_ST=function(v,h){
  var n=h.st(v.w),rows=h.rw(v.l);
  return {parti:[PT("Coperta",rows,n,0,"Avvia "+n+" maglie con ferri circolari: lavori comunque avanti e indietro.\nFerri 1-6: tutti a diritto.\nFerro dritto: tutte a diritto.\nFerro rovescio: 6 dir., a rovescio fino alle ultime 6 maglie, 6 dir.\nRipeti questi due ferri fino a "+Math.max(1,rows-6)+" ferri.\nUltimi 6 ferri: tutti a diritto. Chiudi tutte le maglie.")],
    note:"I 6 ferri a diritto e le 6 maglie ai lati fanno un bordo che non si arriccia."};
};
addTpl(["Coperta","Plaid"],{id:"coperta-bordo",nome:"Coperta in rasato con bordo a legaccio",desc:"Un unico pezzo, con bordo piatto. Serve pazienza, non esperienza.",liv:"Facile",tempo:"30-40 ore",filato:"Lana o acrilico morbido, spessore medio",ferri:"6",unita:"ferri",
  params:[{k:"w",l:"Larghezza (cm)",v:90},{k:"l",l:"Lunghezza (cm)",v:110}],build:COP_ST});
addTpl(["Coperta","Plaid"],{id:"coperta-quadrati",nome:"Coperta a quadrati",desc:"Tanti quadrati uguali da cucire insieme. Si porta ovunque.",liv:"Facile",tempo:"30-40 ore",filato:"Lana o cotone, spessore medio",ferri:"5",unita:"ferri",
  params:[{k:"q",l:"Lato del quadrato (cm)",v:20},{k:"nc",l:"Quadrati in larghezza",v:5},{k:"nr",l:"Quadrati in lunghezza",v:6}],
  build:function(v,h){
    var n=h.st(v.q),rows=h.rw(v.q),nq=v.nc*v.nr;
    return {parti:[PT("Quadrati ("+nq+")",rows*nq,n,0,"Per ogni quadrato: avvia "+n+" maglie, lavora tutti i ferri a diritto per "+rows+" ferri (circa "+v.q+" cm) e chiudi.\nFai "+nq+" quadrati uguali.\nI ferri totali contano tutti i quadrati insieme: segna il numero dei quadrati finiti nelle note.")],
      note:"Cucitura: unisci i quadrati in "+v.nr+" file da "+v.nc+" e poi cuci le file tra loro. Misura finale: circa "+(v.q*v.nc)+" x "+(v.q*v.nr)+" cm."};
  }});
addTpl(["Copertina neonato"],{id:"copertina-riso",nome:"Copertina a punto riso",desc:"Morbida e piatta, senza bordi che si arricciano.",liv:"Facile",tempo:"15-20 ore",filato:"Lana o cotone morbido per neonati",ferri:"4.5",unita:"ferri",
  params:[{k:"w",l:"Larghezza (cm)",v:70},{k:"l",l:"Lunghezza (cm)",v:80}],
  build:function(v,h){
    var n=h.st(v.w,2)+1,rows=h.rw(v.l);
    return {parti:[PT("Copertina",rows,n,2,"Avvia "+n+" maglie (numero dispari).\nOgni ferro: *1 dir., 1 rov.*, ripeti fino all'ultima maglia, 1 dir.\nLavora sempre lo stesso ferro: con un numero dispari di maglie il punto riso si forma da solo.\nContinua fino a "+rowsTxt(h,v.l)+".\nChiudi le maglie come si presentano.")],note:""};
  }});
addTpl(["Strofinaccio"],{id:"strofinaccio-riso",nome:"Strofinaccio a punto riso",desc:"In cotone, rigido e assorbente.",liv:"Facile",tempo:"3-4 ore",filato:"Cotone 100% di spessore medio",ferri:"4",unita:"ferri",
  params:[{k:"w",l:"Larghezza (cm)",v:30},{k:"l",l:"Lunghezza (cm)",v:45}],
  build:function(v,h){
    var n=h.st(v.w,2)+1,rows=h.rw(v.l);
    return {parti:[PT("Strofinaccio",rows,n,2,"Avvia "+n+" maglie (numero dispari).\nOgni ferro: *1 dir., 1 rov.*, ripeti fino all'ultima maglia, 1 dir.\nContinua fino a "+rowsTxt(h,v.l)+".\nChiudi le maglie come si presentano. Nascondi i fili e lava il cotone prima di usarlo.")],note:""};
  }});
addTpl(["Presine"],{id:"presine-legaccio",nome:"Presine a legaccio",desc:"Due quadrati cuciti insieme, con un anello per appenderle.",liv:"Facile",tempo:"2-3 ore",filato:"Cotone 100%, doppio filo",ferri:"4",unita:"ferri",
  params:[{k:"q",l:"Lato (cm)",v:20}],
  build:function(v,h){
    var n=h.st(v.q),rows=h.rw(v.q);
    return {parti:[PT("Due quadrati",rows*2,n,0,"Per ogni quadrato: avvia "+n+" maglie, lavora tutti i ferri a diritto per "+rows+" ferri (circa "+v.q+" cm) e chiudi.\nFai due quadrati uguali.\nAnello: avvia 8 maglie, lavora 5 cm a legaccio, chiudi.")],
      note:"Metti i due quadrati uno sull'altro e cuci i quattro lati con il sopraggitto. Piega l'anello e fissalo in un angolo."};
  }});

var SZ_MAGL={labels:["XS","S","M","L","XL"],def:"M",vals:{}};
[["XS",[80,6,56,58,16,26,4]],["S",[86,6,58,59,17,28,4]],["M",[92,6,60,60,18,30,4]],["L",[100,6,62,61,19,32,4]],["XL",[108,6,64,62,20,34,4]]].forEach(function(z){
  var a=z[1];SZ_MAGL.vals[z[0]]={torace:a[0],agio:a[1],lung:a[2],manica:a[3],polso:a[4],bicipite:a[5],agioM:a[6]};
});
var PARAMS_MAGL=[{k:"torace",l:"Torace (cm)",v:92},{k:"agio",l:"Agio sul torace (cm)",v:6},{k:"lung",l:"Lunghezza del corpo (cm)",v:60},{k:"manica",l:"Lunghezza della manica (cm)",v:60},{k:"polso",l:"Polso finito (cm)",v:18},{k:"bicipite",l:"Bicipite (cm)",v:30},{k:"agioM",l:"Agio sulla manica (cm)",v:4}];
function maglCalc(v,h){
  var circ=v.torace+v.agio,n=h.st(circ/2,2)+2,ribR=h.rw(5),bodyR=h.rw(v.lung),neckW=18;
  var shW=Math.max(4,(circ/2-neckW)/2),shS=h.st(shW,1);
  var pols=h.st(v.polso,2),bics=Math.max(pols,h.st(v.bicipite+v.agioM,2)),incs=(bics-pols)/2,mrows=h.rw(v.manica);
  var gap=incs>0?Math.max(2,Math.floor((mrows-ribR)/incs)):0;
  return {circ:circ,n:n,ribR:ribR,bodyR:bodyR,neckW:neckW,shW:shW,shS:shS,pols:pols,bics:bics,incs:incs,mrows:mrows,gap:gap};
}
function maglDietro(v,h,c){
  return PT("Dietro",c.bodyR,c.n,0,"Avvia "+c.n+" maglie (comprese 2 di vivagno).\nCoste 1/1 per 5 cm ("+c.ribR+" ferri): lavora le maglie come si presentano.\nPassa al rasato (1 ferro a diritto, 1 ferro a rovescio) fino a "+v.lung+" cm dall'avvio, cioè "+c.bodyR+" ferri.\nChiudi tutte le maglie.\nIl collo ("+c.neckW+" cm) resta aperto: le spalle da cucire misurano circa "+fmt(c.shW)+" cm per lato.");
}
function maglManica(nome,v,h,c,prima){
  var istr=prima?"Avvia "+c.pols+" maglie.\nCoste 1/1 per 5 cm ("+c.ribR+" ferri).\nPassa al rasato aumentando 1 maglia per lato ogni "+c.gap+" ferri, per "+c.incs+" volte, fino a "+c.bics+" maglie.\nProsegui dritto fino a "+v.manica+" cm ("+c.mrows+" ferri). Chiudi tutte le maglie.":"Lavora come la manica destra.";
  return PT(nome,c.mrows,c.pols,0,istr);
}
addTpl(["Maglione"],{id:"maglione-spalla-scesa",nome:"Maglione a spalla scesa",desc:"Corpo e maniche in rasato, bordi a coste, scollo rotondo. Si cuce a pezzi.",liv:"Media",tempo:"40-60 ore",filato:"Lana o misto lana, spessore medio",ferri:"4.5",unita:"ferri",
  params:PARAMS_MAGL,taglie:SZ_MAGL,
  build:function(v,h){
    var c=maglCalc(v,h);
    var nc=h.st(8,2),s=Math.max(2,Math.round((c.n-nc)/2)),decs=Math.max(0,s-c.shS),split=Math.max(1,c.bodyR-2*decs);
    var davanti=PT("Davanti",c.bodyR,c.n,0,"Lavora come il dietro fino a "+split+" ferri ("+h.cm(split)+" cm).\nScollo: sul diritto lavora "+s+" maglie, chiudi le "+nc+" maglie centrali e lavora le "+s+" rimaste. Lavora i due lati separatamente.\nSul bordo dello scollo diminuisci 1 maglia ogni 2 ferri per "+decs+" volte: restano "+(s-decs)+" maglie per spalla.\nProsegui dritto fino a "+c.bodyR+" ferri. Chiudi.");
    var collo=PT("Collo",h.rw(2.5),h.st(54,2),2,"Cuci le due spalle. Con ferri circolari riprendi circa "+h.st(54,2)+" maglie intorno allo scollo, chiudi a cerchio.\nGiri di coste 1/1 per 2,5 cm ("+h.rw(2.5)+" giri). Chiudi le maglie come si presentano.");
    return {parti:[maglDietro(v,h,c),davanti,maglManica("Manica destra",v,h,c,true),maglManica("Manica sinistra",v,h,c,false),collo],
      note:"Spalla scesa: cuci il bordo dritto di ogni manica al corpo, a metà della spalla. Poi chiudi il sotto-manica e il fianco con una sola cucitura."};
  }});
addTpl(["Cardigan"],{id:"cardigan-v",nome:"Cardigan con scollo a V",desc:"Davanti separati, bordo a coste con asole. Si cuce a pezzi.",liv:"Media",tempo:"50-70 ore",filato:"Lana o misto lana, spessore medio",ferri:"4.5",unita:"ferri",
  params:PARAMS_MAGL,taglie:SZ_MAGL,
  build:function(v,h){
    var c=maglCalc(v,h),nf=Math.round(c.n/2),decs=Math.max(0,nf-c.shS),split=Math.max(1,c.bodyR-2*decs);
    var front=function(nome,destro){return PT(nome,c.bodyR,nf,0,destro?"Avvia "+nf+" maglie.\nCoste 1/1 per 5 cm ("+c.ribR+" ferri), poi rasato fino a "+split+" ferri ("+h.cm(split)+" cm).\nScollo a V: diminuisci 1 maglia sul bordo anteriore ogni 2 ferri per "+decs+" volte (restano "+(nf-decs)+" maglie per spalla).\nProsegui dritto fino a "+c.bodyR+" ferri. Chiudi.":"Lavora come il davanti destro, ma con le diminuzioni sul lato opposto, a specchio.")};
    var bordoN=Math.round(c.bodyR*3/4)*2+h.st(36,2);
    var bordo=PT("Bordo",h.rw(6),bordoN,2,"Cuci le spalle e le maniche. Riprendi circa 3 maglie ogni 4 ferri lungo tutto il bordo (davanti destro, collo, davanti sinistro): circa "+bordoN+" maglie.\nCoste 1/1 per 6 cm ("+h.rw(6)+" ferri).\nAsole: dopo 2,5 cm, sul bordo destro (per la donna) *chiudi 2 maglie, e sul ferro dopo riavviale*, 5 asole a distanza uguale.\nChiudi le maglie come si presentano.");
    return {parti:[maglDietro(v,h,c),front("Davanti destro",true),front("Davanti sinistro",false),maglManica("Manica destra",v,h,c,true),maglManica("Manica sinistra",v,h,c,false),bordo],
      note:"Cuci i bottoni di fronte alle asole alla fine."};
  }});

/* ---------- Elenco lavori ---------- */
function showList(){
  current={name:"progetti"};
  var cats=catOptions("Maglione");
  view.innerHTML=
  '<section class="head"><h2>I tuoi lavori</h2><button class="btn primary" id="btnNew" type="button">Nuovo lavoro</button></section>'+
  '<form class="panel" id="newForm" hidden>'+
    '<label class="f"><span>Nome del lavoro</span><input type="text" id="nfNome" maxlength="80" placeholder="Es. Maglione girocollo per Marta"></label>'+
    '<label class="f"><span>Che cos\'è</span><select id="nfCat">'+cats+'</select></label>'+
    '<div><p class="eyebrow" style="margin-bottom:6px">Come vuoi partire?</p><div class="chips" style="margin:0" id="nfMode"><button type="button" class="chip" data-m="custom" aria-pressed="true">Faccio io il progetto</button><button type="button" class="chip" data-m="tpl" aria-pressed="false">Scelgo un progetto proposto</button></div></div>'+
    '<div class="grid" id="nfCustom">'+
      '<label class="f"><span>Lavorazione</span><select id="nfUni"><option value="ferri">Ferri dritti (avanti e indietro)</option><option value="giri">In tondo (a giri)</option></select></label>'+
      '<label class="f"><span>Righe totali (facoltativo)</span><input type="number" inputmode="numeric" min="0" id="nfTot" placeholder="Es. 180"></label>'+
    '</div>'+
    '<div id="nfTpl" hidden>'+
      '<div class="tpllist" id="tplList"></div>'+
      '<div class="tpladapt" id="tplAdapt" hidden>'+
        '<h3>Adatta il progetto</h3>'+
        '<p class="note">Cambia le misure o il tuo campione: maglie e ferri si ricalcolano. Dopo aver creato il lavoro potrai modificare ogni numero e ogni istruzione.</p>'+
        '<label class="f" id="tpSizeBox"><span>Taglia</span><select id="tpSize"></select></label>'+
        '<div class="grid" id="tpParams"></div>'+
        '<div class="grid"><label class="f"><span>Maglie in 10 cm</span><input type="text" inputmode="decimal" id="tgMg"></label><label class="f"><span>Ferri in 10 cm</span><input type="text" inputmode="decimal" id="tgFg"></label></div>'+
        '<div id="tpPrev" aria-live="polite"></div>'+
      '</div>'+
    '</div>'+
    '<div class="grid">'+
      '<label class="f"><span>Filato</span><input type="text" id="nfFil" maxlength="80" placeholder="Es. Lana merino, grigio"></label>'+
      '<label class="f"><span>Ferri (mm)</span><input type="text" inputmode="decimal" id="nfFer" maxlength="6" placeholder="Es. 4"></label>'+
    '</div>'+
    '<div class="empty-row" style="display:flex;gap:10px"><button class="btn primary" type="submit">Crea lavoro</button><button class="btn" type="button" id="nfCancel">Annulla</button></div>'+
  '</form>'+
  '<div class="chips" id="chips"></div><div class="cards" id="cards"></div>';
  $("#btnNew").addEventListener("click",function(){var f=$("#newForm");f.hidden=!f.hidden;if(!f.hidden)$("#nfNome").focus()});
  $("#nfCancel").addEventListener("click",function(){$("#newForm").hidden=true});
  setupNewForm();
  updateList();
}
function setupNewForm(){
  var st={mode:"custom",tpl:null};
  var g0=loadGauge();
  $("#tgMg").value=g0.cMg||"20";$("#tgFg").value=g0.cFg||"28";
  function gauge(){var mg=num($("#tgMg").value),fg=num($("#tgFg").value);return {mg:mg>0?mg:20,fg:fg>0?fg:28}}
  function vals(){
    var v={};
    st.tpl.params.forEach(function(q){var n=num($("#tp_"+q.k).value);v[q.k]=n>=0?n:q.v});
    return v;
  }
  function preview(){
    var box=$("#tpPrev");
    if(!st.tpl){box.innerHTML="";return}
    var b=st.tpl.build(vals(),tplHelpers(gauge())),U2=UN[st.tpl.unita]||UN.ferri;
    box.innerHTML='<p class="eyebrow" style="margin-bottom:6px">Il progetto, con le tue misure</p><ul class="steps" style="padding-left:18px">'+
      b.parti.map(function(x){return "<li><b>"+esc(x.nome)+"</b> · "+x.maglie+" maglie · "+x.totale+" "+U2.p+"</li>"}).join("")+"</ul>";
  }
  function drawParams(){
    var t=st.tpl;
    $("#tpParams").innerHTML=t.params.map(function(q){
      return '<label class="f"><span>'+esc(q.l)+'</span><input type="text" inputmode="decimal" id="tp_'+q.k+'" value="'+q.v+'"></label>';
    }).join("");
    t.params.forEach(function(q){$("#tp_"+q.k).addEventListener("input",preview)});
    var box=$("#tpSizeBox");box.hidden=!t.taglie;
    if(t.taglie){
      $("#tpSize").innerHTML=t.taglie.labels.map(function(l){return "<option"+(l===t.taglie.def?" selected":"")+">"+esc(l)+"</option>"}).join("");
      applySize();
    }
    preview();
  }
  function applySize(){
    var t=st.tpl;if(!t||!t.taglie)return;
    var vv=t.taglie.vals[$("#tpSize").value]||{};
    Object.keys(vv).forEach(function(k){var el=$("#tp_"+k);if(el)el.value=vv[k]});
  }
  function drawList(){
    var cat=$("#nfCat").value,list=TPL[cat]||[];
    st.tpl=null;$("#tplAdapt").hidden=true;
    $("#tplList").innerHTML=list.length?list.map(function(t){
      return '<label class="tplcard"><input type="radio" name="tpl" value="'+t.id+'"><span class="tc"><b>'+esc(t.nome)+'</b><small>'+esc(t.desc)+'</small><small class="tm">'+esc(t.liv)+' · circa '+esc(t.tempo)+'</small></span></label>';
    }).join(""):'<p class="hint">Per questo capo non ci sono ancora progetti proposti. Scegli "Faccio io il progetto".</p>';
    $("#tplList").querySelectorAll("input").forEach(function(r){r.addEventListener("change",function(){
      st.tpl=list.find(function(t){return t.id===r.value});
      $("#tplAdapt").hidden=false;
      $("#nfFil").value=st.tpl.filato;$("#nfFer").value=st.tpl.ferri;
      drawParams();
    })});
  }
  function setMode(m){
    st.mode=m;
    document.querySelectorAll("#nfMode .chip").forEach(function(b){b.setAttribute("aria-pressed",String(b.getAttribute("data-m")===m))});
    $("#nfCustom").hidden=m!=="custom";$("#nfTpl").hidden=m!=="tpl";
    if(m==="tpl")drawList();
  }
  document.querySelectorAll("#nfMode .chip").forEach(function(b){b.addEventListener("click",function(){setMode(b.getAttribute("data-m"))})});
  $("#nfCat").addEventListener("change",function(){if(st.mode==="tpl")drawList()});
  $("#tpSize").addEventListener("change",function(){applySize();preview()});
  $("#tgMg").addEventListener("input",preview);$("#tgFg").addEventListener("input",preview);
  $("#newForm").addEventListener("submit",function(e){
    e.preventDefault();
    var cat=$("#nfCat").value,nome=$("#nfNome").value.trim();
    if(st.mode==="tpl"){
      if(!st.tpl){toast("Scegli un progetto proposto");return}
      var t=st.tpl,gg=gauge(),b=t.build(vals(),tplHelpers(gg));
      var parti=b.parti.map(function(x){return {id:newId(),nome:x.nome,riga:0,totale:x.totale,rip:x.rip,maglie:x.maglie,mlav:0,auto:false,fatta:false,istr:x.istr,unita:t.unita}});
      var p=addProject({nome:nome||t.nome,categoria:cat,unita:t.unita,filato:$("#nfFil").value.trim(),ferri:$("#nfFer").value.trim(),parti:parti,note:b.note||"",modello:t.id});
      p.parteAttiva=parti[0].id;persist(p,0);
      try{var gs=loadGauge();gs.cMg=$("#tgMg").value;gs.cFg=$("#tgFg").value;localStorage.setItem(LSG,JSON.stringify(gs))}catch(x){}
      location.hash="lavoro-"+p.id;return;
    }
    if(!nome){toast("Scrivi il nome del lavoro");$("#nfNome").focus();return}
    var p2=addProject({nome:nome,categoria:cat,unita:$("#nfUni").value,filato:$("#nfFil").value.trim(),ferri:$("#nfFer").value.trim(),totale:toInt($("#nfTot").value)});
    location.hash="lavoro-"+p2.id;
  });
}
function updateList(){
  var counts={tutti:projects.length,incorso:0,pausa:0,finito:0};
  projects.forEach(function(p){if(counts[p.stato]!=null)counts[p.stato]++});
  var defs=[["tutti","Tutti"],["incorso","In corso"],["pausa","In pausa"],["finito","Finiti"]];
  $("#chips").innerHTML=projects.length?defs.map(function(d){
    return '<button type="button" class="chip" data-f="'+d[0]+'" aria-pressed="'+(filter===d[0])+'">'+d[1]+" · "+counts[d[0]]+"</button>";
  }).join(""):"";
  $("#chips").querySelectorAll(".chip").forEach(function(b){b.addEventListener("click",function(){filter=b.getAttribute("data-f");updateList()})});

  var box=$("#cards");
  if(!projects.length){
    box.innerHTML='<div class="empty"><h3>Ancora nessun lavoro</h3><p class="hint">Qui compariranno i tuoi progetti, ognuno con contarighe, ferri usati, filato e note.</p><div class="row"><button class="btn primary" type="button" id="emNew">Aggiungi il primo lavoro</button><button class="btn" type="button" id="emDemo">Prova con un esempio</button></div></div>';
    $("#emNew").addEventListener("click",function(){$("#newForm").hidden=false;$("#nfNome").focus()});
    $("#emDemo").addEventListener("click",function(){
      var p=addProject({nome:"Sciarpa a coste (esempio)",categoria:"Sciarpa",filato:"Lana merino grigia",ferri:"4",riga:36,totale:200,rip:4,note:"Esempio: puoi modificarlo o eliminarlo quando vuoi."});
      location.hash="lavoro-"+p.id;
    });
    return;
  }
  var list=projects.filter(function(p){return filter==="tutti"||p.stato===filter}).sort(function(a,b){return (b.aggiornato||0)-(a.aggiornato||0)});
  if(!list.length){box.innerHTML='<p class="hint">Nessun lavoro in questa categoria.</p>';return}
  box.innerHTML=list.map(function(p){
    var u=U(p),meta=[p.categoria,p.filato,p.ferri?"ferri "+p.ferri+" mm":""].filter(Boolean).map(esc).join(" · ");
    var ps=p.parti||[],t=T(p),pg=progress(p);
    var line=ps.length?(ps.length+" parti · "+(pg.has?pg.pct+"% · ":"")+ago(p.aggiornato||p.creato)):(u.S+" "+p.riga+(p.totale>0?" di "+p.totale+" · "+pct(p)+"%":"")+" · "+ago(p.aggiornato||p.creato));
    var on=Math.round(pg.pct/100*24);if(pg.pct>0&&on===0)on=1;
    return '<article class="card"><a class="card-main" href="#lavoro-'+esc(p.id)+'">'+
      '<div class="card-top"><h3>'+esc(p.nome||"Senza nome")+'</h3><span class="pill st-'+esc(p.stato)+'">'+esc(STATI[p.stato]||"")+'</span></div>'+
      (meta?'<p class="meta">'+meta+"</p>":"")+(pg.has?segN(on):"")+
      '<p class="meta">'+esc(line)+"</p></a>"+
      '<div class="acts">'+
      (p.stato==="incorso"?'<button type="button" class="btn quick" data-inc="'+esc(p.id)+'" aria-label="Aggiungi un '+u.s+' a '+esc(p.nome||"questo lavoro")+'">+1</button>':"")+
      '<button type="button" class="iconbtn'+(armedDel===p.id?" armed":"")+'" data-del="'+esc(p.id)+'" aria-label="'+(armedDel===p.id?"Conferma: elimina ":"Elimina ")+esc(p.nome||"questo lavoro")+'">'+TRASH+'<span class="lbl">Elimina?</span></button></div>'+
      "</article>";
  }).join("");
  box.querySelectorAll("[data-inc]").forEach(function(b){
    b.addEventListener("click",function(){
      var p=projects.find(function(x){return x.id===b.getAttribute("data-inc")});
      if(p){var t=T(p);t.riga=Math.min(99999,t.riga+1);t.mlav=0;vib();persist(p);updateList()}
    });
  });
  box.querySelectorAll("[data-del]").forEach(function(b){
    b.addEventListener("click",function(){
      var id=b.getAttribute("data-del");
      if(armedDel===id){clearTimeout(armT);removeProject(id);return}
      armedDel=id;updateList();
      clearTimeout(armT);
      armT=setTimeout(function(){armedDel=null;if(current.name==="progetti")updateList()},4000);
    });
  });
}

/* ---------- Parti del lavoro e disegno ---------- */
var gfxTab="finale";
function colorOf(p){return /^#[0-9a-fA-F]{6}$/.test(p.colore||"")?p.colore:"#E8688F"}
/* Con le parti, il contatore lavora sulla parte scelta; senza parti, sul lavoro intero. */
function T(p){
  var a=p.parti;
  if(!a||!a.length)return p;
  var t=a.find(function(x){return x.id===p.parteAttiva})||a[0];
  p.parteAttiva=t.id;t.unita=p.unita;return t;
}
function partProg(t){return t.fatta?1:(t.totale>0?Math.min(1,t.riga/t.totale):0)}
function overall(p){
  var a=p.parti||[];
  if(a.length)return a.reduce(function(s,t){return s+partProg(t)},0)/a.length;
  return p.totale>0?Math.min(1,p.riga/p.totale):0;
}
function progress(p){
  var a=p.parti||[];
  var has=a.length?a.some(function(t){return t.fatta||t.totale>0}):p.totale>0;
  return {has:has,pct:Math.round(overall(p)*100)};
}

var P5=["Dietro","Davanti destro","Davanti sinistro","Manica destra","Manica sinistra"];
var MANI=["Mano destra","Mano sinistra","Pollice destro","Pollice sinistro"];
var CALZA=["Gambale","Tallone","Piede","Punta"];
var PARTI_SUGG={
  "Maglione":["Dietro","Davanti","Manica destra","Manica sinistra","Cappuccio","Collo"],
  "Cardigan":["Dietro","Davanti destro","Davanti sinistro","Manica destra","Manica sinistra","Cappuccio","Bordo"],
  "Gilet":["Dietro","Davanti","Bordo del collo"],
  "Top e canotta":["Dietro","Davanti"],
  "Vestito":["Corpetto","Gonna","Manica destra","Manica sinistra"],
  "Gonna":["Davanti","Dietro","Cintura"],
  "Pantaloni":["Gamba destra","Gamba sinistra","Cintura"],
  "Poncho e mantella":["Davanti","Dietro","Collo"],
  "Scialle":["Corpo","Bordo"],"Stola":["Corpo","Bordo"],"Scaldacollo":["Corpo","Bordo"],
  "Cappello":["Bordo","Corpo","Cima"],
  "Guanti":MANI,"Mezzeguanti":MANI,"Muffole":MANI,
  "Calze":CALZA,"Calzettoni":CALZA,
  "Pantofole":["Suola","Tomaia"],
  "Borsa":["Fronte","Retro","Manici"],
  "Coperta":["Quadrato 1","Quadrato 2","Bordo"],"Plaid":["Quadrato 1","Quadrato 2","Bordo"],
  "Copertina neonato":["Corpo","Bordo"],
  "Tutina e body":["Dietro","Davanti","Manica destra","Manica sinistra"],
  "Giacchino neonato":P5,
  "Peluche":["Corpo","Testa","Braccia","Gambe","Orecchie"]
};

var PIECE={
  davanti:{w:96,h:120,d:"M0 12 Q0 0 12 0 H34 Q48 26 62 0 H84 Q96 0 96 12 V120 H0 Z"},
  dietro:{w:96,h:120,d:"M0 12 Q0 0 12 0 H36 Q48 8 60 0 H84 Q96 0 96 12 V120 H0 Z"},
  davantino:{w:52,h:120,d:"M0 0 H38 Q52 0 52 14 V120 H0 Z",flip:1},
  manica:{w:80,h:120,d:"M0 0 H80 L58 120 H22 Z"},
  cappuccio:{w:84,h:96,d:"M0 96 V34 Q0 0 42 0 Q84 0 84 34 V96 Z"},
  striscia:{w:120,h:24,d:"M6 0 H114 Q120 0 120 6 V18 Q120 24 114 24 H6 Q0 24 0 18 V6 Q0 0 6 0 Z"},
  pollice:{w:36,h:56,d:"M0 56 V18 Q0 0 18 0 Q36 0 36 18 V56 Z",flip:1},
  guanto:{w:76,h:110,d:"M0 110 V40 Q0 0 30 0 Q58 0 58 40 V50 L70 36 Q76 44 70 58 L58 76 V110 Z",flip:1},
  cupola:{w:100,h:90,d:"M0 90 V44 Q0 0 50 0 Q100 0 100 44 V90 Z"},
  rettangolo:{w:90,h:100,d:"M0 0 H90 V100 H0 Z"}
};
function shapeFor(nome,cat){
  var n=String(nome).toLowerCase(),cap=/cappell/i.test(cat);
  if(/cappuccio/.test(n))return "cappuccio";
  if(/manica|maniche/.test(n))return "manica";
  if(/davanti\s+(destr|sinistr)/.test(n))return "davantino";
  if(/davanti|fronte|corpetto/.test(n))return "davanti";
  if(/dietro|retro/.test(n))return "dietro";
  if(/collo|colletto|bordo|bordi|cintura|manici/.test(n))return "striscia";
  if(/pollice/.test(n))return "pollice";
  if(/mano|guanto/.test(n))return "guanto";
  return cap?"cupola":"rettangolo";
}

function circ(cx,cy,r){return "M"+(cx-r)+" "+cy+" a"+r+" "+r+" 0 1 0 "+(2*r)+" 0 a"+r+" "+r+" 0 1 0 "+(-2*r)+" 0Z"}
var TOP_D="M82 18 Q120 44 158 18 L206 38 L234 148 L202 160 L184 104 L184 206 L56 206 L56 104 L38 160 L6 148 L34 38 Z";
var GILET_D="M82 18 Q120 44 158 18 L190 30 L196 70 Q184 90 184 110 L184 206 L56 206 L56 110 Q56 90 44 70 L50 30 Z";
var NECK='<path d="M82 18 Q120 44 158 18 Q120 6 82 18Z" class="g-dk"/>';
var TOP_DECO=NECK+'<path d="M56 190 H184 M9 136 L40 148 M231 136 L200 148" class="g-ln"/>';
var CARD_DECO=TOP_DECO+'<path d="M120 38 V206" class="g-ln g-dash"/>'+[70,100,130,160,190].map(function(y){return '<circle cx="132" cy="'+y+'" r="4" class="g-bt"/>'}).join("");
var GILET_DECO=NECK+'<path d="M56 190 H184" class="g-ln"/>';
var FRINGE=function(x1,x2,y1,y2){var s="";for(var x=x1;x<=x2;x+=8)s+="M"+x+" "+y1+" V"+y2+" ";return '<path d="'+s+'" class="g-ln"/>'};
var SIL={
  top:{ds:[TOP_D],deco:TOP_DECO},
  cardigan:{ds:[TOP_D],deco:CARD_DECO},
  gilet:{ds:[GILET_D],deco:GILET_DECO},
  vestito:{ds:["M82 18 Q120 44 158 18 L200 34 L224 124 L196 132 L180 96 L208 214 L32 214 L60 96 L44 132 L16 124 L40 34 Z"],deco:NECK+'<path d="M52 198 H188" class="g-ln"/>'},
  poncho:{ds:["M82 18 Q120 40 158 18 L232 132 Q120 196 8 132 Z"],deco:NECK+'<path d="M30 150 Q120 196 210 150" class="g-ln"/>'},
  gonna:{ds:["M70 20 L170 20 L208 204 L32 204 Z"],deco:'<path d="M70 40 H170 M44 190 H196" class="g-ln"/>'},
  pantaloni:{ds:["M64 10 L176 10 L192 212 L130 212 L120 84 L110 212 L48 212 Z"],deco:'<path d="M64 30 H176 M53 196 H112 M128 196 H187" class="g-ln"/>'},
  sciarpa:{ds:["M80 -10 Q120 2 160 -10 L160 198 Q120 210 80 198 Z"],deco:'<path d="M80 18 Q120 30 160 18 M80 178 Q120 190 160 178" class="g-ln"/>'+FRINGE(86,154,204,222)},
  stola:{ds:["M12 60 Q120 72 228 60 L228 160 Q120 172 12 160 Z"],deco:'<path d="M40 64 V164 M200 64 V164" class="g-ln"/>'},
  scialle:{ds:["M8 30 Q120 0 232 30 L120 208 Z"],deco:'<path d="M26 40 Q120 14 214 40" class="g-ln"/>'},
  tubo:{ds:["M50 40 Q120 10 190 40 L196 152 Q120 192 44 152 Z"],deco:'<path d="M50 40 Q120 70 190 40" class="g-ln"/><path d="M46 130 Q120 170 194 130" class="g-ln"/>'},
  cappello:{ds:["M50 150 Q38 30 120 22 Q202 30 190 150 Z","M44 150 H196 V190 Q196 198 188 198 H52 Q44 198 44 190 Z",circ(120,12,22)],deco:'<path d="M44 172 H196" class="g-ln"/>'},
  fascia:{ds:["M16 84 Q120 62 224 84 V142 Q120 120 16 142 Z"],deco:'<path d="M16 113 Q120 91 224 113" class="g-ln g-dash"/>'},
  guanto:{ds:["M64 210 V90 Q64 6 118 6 Q172 6 172 90 V120 L196 96 Q214 84 226 100 Q234 116 214 140 L180 176 V210 Z"],deco:'<path d="M64 176 H180" class="g-ln"/>'},
  calza:{ds:["M78 -10 H150 V110 Q150 124 164 130 L200 148 Q222 160 214 182 Q206 200 184 200 H96 Q78 200 78 180 Z"],deco:'<path d="M78 18 H150 M78 40 H150" class="g-ln"/>'},
  pantofola:{ds:["M28 150 Q18 92 90 82 L180 92 Q224 102 216 150 Q212 192 150 194 H60 Q32 192 28 150 Z"],deco:'<path d="M70 102 Q120 82 172 106 Q150 134 90 128 Z" class="g-dk"/>'},
  borsa:{ds:["M40 90 H200 V200 Q200 210 190 210 H50 Q40 210 40 200 Z","M70 90 Q70 14 120 14 Q170 14 170 90 H152 Q152 36 120 36 Q88 36 88 90 Z"],deco:'<path d="M40 112 H200" class="g-ln"/>'},
  coperta:{ds:["M16 28 Q120 18 224 28 V204 Q120 214 16 204 Z"],deco:'<path d="M34 46 H206 V186 H34 Z" class="g-ln g-dash"/>'},
  cuscino:{ds:["M36 40 H204 V200 H36 Z"],deco:'<circle cx="120" cy="120" r="5" class="g-bt"/><path d="M52 56 H188 V184 H52 Z" class="g-ln g-dash"/>'},
  cestino:{ds:["M36 80 H204 L186 200 Q184 212 172 212 H68 Q56 212 54 200 Z"],deco:'<path d="M36 80 H204 M46 120 H194 M52 160 H188" class="g-ln"/>'},
  peluche:{ds:[circ(120,72,46),circ(84,32,18),circ(156,32,18),circ(120,164,52),circ(58,150,24),circ(182,150,24)],deco:'<circle cx="104" cy="68" r="4" class="g-bt"/><circle cx="136" cy="68" r="4" class="g-bt"/><ellipse cx="120" cy="86" rx="8" ry="6" class="g-dk"/>'},
  fiore:{ds:[circ(120,58,34),circ(166,92,34),circ(148,148,34),circ(92,148,34),circ(74,92,34),circ(120,112,24)],deco:'<circle cx="120" cy="112" r="10" class="g-dk"/>'},
  albero:{ds:["M120 6 L190 92 H156 L206 164 H138 V208 H102 V164 H34 L84 92 H50 Z"],deco:'<circle cx="112" cy="70" r="4" class="g-bt"/><circle cx="130" cy="120" r="4" class="g-bt"/><circle cx="96" cy="140" r="4" class="g-bt"/>'},
  generico:{ds:["M36 36 Q120 24 204 36 V204 Q120 216 36 204 Z"],deco:'<path d="M52 56 H188 V184 H52 Z" class="g-ln g-dash"/>'}
};
var SILK={"Maglione":"top","Cardigan":"cardigan","Gilet":"gilet","Top e canotta":"gilet","Vestito":"vestito","Gonna":"gonna","Pantaloni":"pantaloni","Poncho e mantella":"poncho",
  "Sciarpa":"sciarpa","Scialle":"scialle","Stola":"stola","Scaldacollo":"tubo","Scaldamuscoli":"tubo","Cappello":"cappello","Cappellino neonato":"cappello","Fascia per capelli":"fascia",
  "Guanti":"guanto","Mezzeguanti":"guanto","Muffole":"guanto","Calze":"calza","Calzettoni":"calza","Pantofole":"pantofola","Scarpine neonato":"pantofola","Borsa":"borsa",
  "Coperta":"coperta","Plaid":"coperta","Copertina neonato":"coperta","Copricuscino":"cuscino","Presine":"cuscino","Strofinaccio":"cuscino","Cestino":"cestino",
  "Tutina e body":"top","Giacchino neonato":"cardigan","Peluche":"peluche","Fiori e decorazioni":"fiore","Decorazioni natalizie":"albero","Altro":"generico"};
var HOOD_D="M72 26 Q56 -18 120 -18 Q184 -18 168 26 Q120 50 72 26Z";
var PAT='<pattern id="kn" width="12" height="10" patternUnits="userSpaceOnUse"><path d="M1 1 L6 8 L11 1" fill="none" stroke="#000" stroke-opacity=".22" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></pattern>';

function silSvg(p,frac,col){
  var key=SILK[p.categoria]||"generico",s=SIL[key]||SIL.generico,ds=s.ds.slice();
  var hood=(p.parti||[]).some(function(t){return /cappuccio/i.test(t.nome)})&&(key==="top"||key==="cardigan"||key==="gilet");
  if(hood)ds.unshift(HOOD_D);
  var all=ds.map(function(d){return '<path d="'+d+'"/>'}).join("");
  var h=Math.round(240*Math.max(0,Math.min(1,frac))),y=220-h;
  var o='<svg viewBox="0 -20 240 240" role="img" aria-label="Disegno del lavoro: '+esc(p.categoria)+'"><defs>'+PAT+
    '<clipPath id="silc">'+all+'</clipPath><clipPath id="fillc"><rect x="0" y="'+y+'" width="240" height="'+h+'"/></clipPath></defs>'+
    '<g class="g-empty">'+all+'</g>';
  if(h>0){
    o+='<g clip-path="url(#silc)"><rect x="0" y="'+y+'" width="240" height="'+h+'" style="fill:'+col+'"/><rect x="0" y="'+y+'" width="240" height="'+h+'" fill="url(#kn)"/></g>';
    o+='<g clip-path="url(#fillc)">'+s.deco+"</g>";
  }
  return o+'<g class="g-line">'+all+"</g></svg>";
}
function piecesSvg(p,col,full){
  var W=360,items=p.parti.map(function(t,i){
    var k=shapeFor(t.nome,p.categoria),sh=PIECE[k];
    return {t:t,sh:sh,i:i,flip:!!sh.flip&&/sinistr/i.test(t.nome),pr:full?1:partProg(t),cell:Math.max(sh.w,full?110:84)};
  });
  var x=8,y=10,rowH=0;
  items.forEach(function(it){
    if(x+it.cell>W-8&&x>8){x=8;y+=rowH+46;rowH=0}
    it.x=x+(it.cell-it.sh.w)/2;it.y=y;x+=it.cell+8;rowH=Math.max(rowH,it.sh.h);
  });
  var H=y+rowH+46;
  var o='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="Avanzamento delle parti del lavoro" style="max-width:440px"><defs>'+PAT+"</defs>";
  items.forEach(function(it){
    var w=it.sh.w,h=it.sh.h,d=it.sh.d,pr=it.pr;
    var nm=it.t.nome.length>15?it.t.nome.slice(0,14)+"…":it.t.nome;
    o+='<g transform="translate('+it.x.toFixed(1)+' '+it.y+')"><g'+(it.flip?' transform="translate('+w+' 0) scale(-1 1)"':"")+">"+
      '<clipPath id="pc'+it.i+'"><path d="'+d+'"/></clipPath><path d="'+d+'" class="g-empty"/>'+
      (pr>0?'<g clip-path="url(#pc'+it.i+')"><rect x="0" y="'+(h*(1-pr)).toFixed(1)+'" width="'+w+'" height="'+(h*pr).toFixed(1)+'" style="fill:'+col+'"/><rect x="0" y="'+(h*(1-pr)).toFixed(1)+'" width="'+w+'" height="'+(h*pr).toFixed(1)+'" fill="url(#kn)"/></g>':"")+
      '<path d="'+d+'" class="g-line"/></g>'+
      '<text x="'+w/2+'" y="'+(h+16)+'" text-anchor="middle" class="g-txt">'+esc(nm)+"</text>"+
      '<text x="'+w/2+'" y="'+(h+30)+'" text-anchor="middle" class="g-txt2">'+(full?((it.t.maglie>0?it.t.maglie+" mg":"")+(it.t.maglie>0&&it.t.totale>0?" × ":"")+(it.t.totale>0?it.t.totale+" "+(UN[it.t.unita]||UN.ferri).p:"")):(it.t.fatta?"finita":Math.round(pr*100)+"%"))+"</text></g>";
  });
  return o+"</svg>";
}
function drawGfx(p){
  var box=$("#gfxSvg");if(!box)return;
  var col=colorOf(p),has=(p.parti||[]).length>0,pg=progress(p);
  document.querySelectorAll("#gfxTabs .chip").forEach(function(b){b.setAttribute("aria-pressed",String(b.getAttribute("data-t")===gfxTab))});
  var cap;
  if(gfxTab==="finale"){box.innerHTML=silSvg(p,1,col);cap="Così apparirà il lavoro finito, nel colore del tuo filato."}
  else{
    box.innerHTML=has?piecesSvg(p,col):silSvg(p,overall(p),col);
    cap=pg.has?("Avanzamento complessivo: "+pg.pct+"%."+(has?" Ogni pezzo si riempie dal basso, come il lavoro sui ferri.":"")):
      (has?"Imposta i ferri totali di ogni parte, o segna le parti finite, per vedere i pezzi riempirsi.":"Imposta i ferri totali del lavoro per vedere il disegno riempirsi dal basso.");
  }
  $("#gfxCap").textContent=cap;
}
function addParts(p,names){
  var carry=!(p.parti&&p.parti.length)&&(p.riga>0||p.totale>0||p.maglie>0||p.mlav>0||p.rip>0);
  p.parti=p.parti||[];
  var first=null;
  names.forEach(function(n,i){
    var t={id:newId(),nome:n,riga:0,totale:0,rip:0,maglie:0,mlav:0,auto:false,fatta:false,istr:"",unita:p.unita};
    if(carry&&i===0){
      t.riga=p.riga;t.totale=p.totale;t.rip=p.rip;t.maglie=p.maglie;t.mlav=p.mlav;t.auto=p.auto;
      p.riga=0;p.totale=0;p.rip=0;p.maglie=0;p.mlav=0;p.auto=false;
    }
    p.parti.push(t);if(!first)first=t;
  });
  if(first)p.parteAttiva=first.id;
  hist=[];persist(p);refreshCounter(p,false);
  toast(names.length>1?"Parti aggiunte":"Parte aggiunta");
}
function refreshParts(p){
  var list=$("#partList");if(!list)return;
  var ps=p.parti||[],t=T(p);
  list.innerHTML=ps.length?ps.map(function(x){
    var pr=partProg(x),on=Math.round(pr*24);if(pr>0&&on===0)on=1;
    return '<button type="button" class="part'+(x.id===t.id?" on":"")+'" data-part="'+esc(x.id)+'" aria-pressed="'+(x.id===t.id)+'">'+
      '<span class="row"><span>'+esc(x.nome)+'</span><span class="pm">'+(x.fatta?"Finita":(x.totale>0?Math.round(pr*100)+"%":(x.riga>0?U(p).S+" "+x.riga:"da iniziare")))+"</span></span>"+segN(on)+"</button>";
  }).join(""):'<p class="hint">Stai lavorando il pezzo intero. Dividi il lavoro in parti se devi lavorare davanti, dietro, maniche e poi cucirle.</p>';
  var have=ps.map(function(x){return x.nome.toLowerCase()});
  var missing=(PARTI_SUGG[p.categoria]||["Parte 1","Parte 2"]).filter(function(n){return have.indexOf(n.toLowerCase())<0});
  $("#partSuggest").innerHTML=missing.length?'<p class="eyebrow" style="margin-bottom:6px">Parti consigliate per '+esc(p.categoria.toLowerCase())+'</p><div class="chips" style="margin:0">'+
    missing.map(function(n){return '<button type="button" class="chip" data-add="'+esc(n)+'">+ '+esc(n)+"</button>"}).join("")+
    (missing.length>1?'<button type="button" class="chip" data-all="1">Aggiungi tutte</button>':"")+"</div>":"";
  var ed=$("#partEdit");ed.hidden=!ps.length;
  if(ps.length){
    var inp=$("#dParte");if(document.activeElement!==inp)inp.value=t.nome;
    $("#bFatta").textContent=t.fatta?"Riapri questa parte":"Segna questa parte come finita";
    var ist=$("#dIstr");if(document.activeElement!==ist)ist.value=t.istr||"";
  }
}

/* ---------- Cucitura ---------- */
var SEAMS={
  materasso:{n:"Punto materasso",liv:"Facile",
    uso:"Cucitura invisibile sui lati del lavoro a maglia rasata: fianchi, sotto le maniche, lati del cappello.",
    asp:"Si vede quasi niente, sul diritto, e resta elastica.",
    come:["Appoggia i due pezzi affiancati, con il diritto verso di te e i bordi a contatto, ferro con ferro.","Infila un ago da lana con un filo dello stesso colore, lungo circa tre volte la cucitura.","Sul primo pezzo passa l'ago sotto le barrette orizzontali che collegano le prime due maglie del bordo.","Ripeti sul secondo pezzo, alla stessa altezza.","Continua alternando i due pezzi. Dopo 4 o 5 punti tira piano il filo: la cucitura si chiude e sparisce.","Cuci un ferro con un ferro e controlla ogni tanto che i due pezzi restino della stessa lunghezza."],
    yt:"punto materasso ai ferri cucitura tutorial"},
  tre_ferri:{n:"Chiusura a tre ferri",liv:"Media",
    uso:"Unisce due pezzi con le maglie ancora sui ferri: spalle, sommità del cappuccio, chiusure a cerchio.",
    asp:"Robusta e piatta, con una piccola cresta sul rovescio.",
    come:["Lascia le maglie dei due pezzi su due ferri, con i diritti uno contro l'altro e le punte rivolte nella stessa direzione.","Con un terzo ferro infila la prima maglia del ferro davanti e la prima del ferro dietro, insieme, e lavorale a diritto come una maglia sola.","Fai lo stesso con le due maglie successive.","Accavalla la prima maglia sulla seconda, come in una chiusura normale.","Continua fino alla fine del ferro, poi taglia il filo e passalo nell'ultima maglia."],
    yt:"chiusura a tre ferri ai ferri tutorial"},
  tessitura:{n:"Tessitura (punto maglia invisibile)",liv:"Più difficile",
    uso:"Unisce due serie di maglie ancora sui ferri senza che si veda l'unione: punta delle calze, sommità del cappuccio, chiusura di uno scaldacollo.",
    asp:"Invisibile, sembra un'unica fila di maglie.",
    come:["Metti i due ferri paralleli, con i diritti verso l'esterno, e lascia un filo lungo circa quattro volte la larghezza.","Preparazione: infila l'ago nella prima maglia davanti come per lavorarla a rovescio e lasciala sul ferro. Poi infilalo nella prima maglia dietro come a diritto e lasciala sul ferro.","Davanti: infila l'ago a diritto nella prima maglia e sfilala. Poi infila a rovescio nella maglia seguente e lasciala sul ferro.","Dietro: infila l'ago a rovescio nella prima maglia e sfilala. Poi infila a diritto nella maglia seguente e lasciala sul ferro.","Ripeti questi due passaggi fino alla fine, tirando il filo piano per avere la stessa tensione delle altre maglie."],
    yt:"tessitura punto maglia invisibile kitchener tutorial"},
  sopraggitto:{n:"Sopraggitto",liv:"Facile",
    uso:"Unisce pezzi piccoli o che non devono essere invisibili: borse, cuscini, peluche, suole.",
    asp:"Piatta e veloce, ma si vede il filo sul bordo.",
    come:["Metti i pezzi uno sull'altro con i bordi allineati, diritto contro diritto se vuoi la cucitura all'interno.","Infila l'ago da dietro nel primo pezzo, vicino al bordo.","Passa il filo sopra i bordi e infila l'ago da dietro anche nel secondo pezzo, a una maglia di distanza.","Fai punti piccoli e regolari senza tirare troppo, così la cucitura non arriccia.","Fissa il filo con due punti sovrapposti a fine cucitura."],
    yt:"sopraggitto cucitura lavoro a maglia tutorial"},
  indietro:{n:"Punto indietro",liv:"Facile",
    uso:"Cucitura solida per borse, spalle e punti che si tirano, come cavallo dei pantaloni e maniche pesanti.",
    asp:"Molto resistente, forma una piccola cresta sul rovescio.",
    come:["Metti i pezzi diritto contro diritto e fissali con spilli o fermagli.","Fai il primo punto a una maglia dal bordo.","Torna indietro e infila l'ago nel punto di uscita del filo, poi avanza di un punto.","Ripeti: ogni punto parte dal foro del precedente, così il filo resta continuo.","Apri la cucitura sul rovescio e stirala con il vapore, se il filato lo permette."],
    yt:"punto indietro cucitura maglia tutorial"},
  giromanica:{n:"Manica nel giromanica",liv:"Media",
    uso:"Per attaccare la testa della manica al giromanica del corpo, che è un incavo curvo.",
    asp:"Pulita e senza arricciature, se i due bordi sono distribuiti bene.",
    come:["Chiudi prima le spalle. Tieni la manica aperta e piatta.","Appunta il centro della testa della manica alla cucitura della spalla.","Appunta anche i due punti sotto l'ascella e distribuisci il resto con gli spilli.","Cuci con il punto materasso, a una maglia dal bordo. Dove la manica è più larga ammorbidisci il filo.","Chiudi poi il sotto-manica e il fianco con un'unica cucitura continua."],
    yt:"cucire le maniche giromanica ai ferri tutorial"},
  riprendi:{n:"Riprendere le maglie",liv:"Media",
    uso:"Per collo, bordi dei davanti e bordi di coperte: crei maglie nuove lungo un bordo già lavorato e prosegui da lì.",
    asp:"Il bordo nasce dal lavoro, senza cucitura.",
    come:["Tieni il lavoro con il diritto verso di te.","Infila il ferro o un uncinetto nel bordo, sotto il filo del vivagno.","Passa il filo e tira un'asola: è la prima maglia ripresa.","Ripeti lungo il bordo. Sul rasato riprendi circa 3 maglie ogni 4 ferri; sul legaccio una maglia in ogni cresta.","Conta le maglie e distribuiscile in modo uniforme, poi lavora il bordo."],
    yt:"riprendere le maglie ai ferri tutorial"},
  cima:{n:"Chiudere la cima",liv:"Facile",
    uso:"Per chiudere la sommità di un cappello lavorato in tondo.",
    asp:"Il cerchio si chiude e resta piatto.",
    come:["Taglia il filo lasciando circa 30 cm e infilalo in un ago da lana.","Passa l'ago in tutte le maglie rimaste, sfilandole dal ferro una alla volta.","Tira il filo per chiudere il cerchio.","Fai due o tre punti per fissare e nascondi il filo all'interno."],
    yt:"chiudere la cima del cappello ai ferri tutorial"},
  bottoni:{n:"Cucire i bottoni",liv:"Facile",
    uso:"Per fissare i bottoni di fronte alle asole.",
    asp:"Il gambo lascia il bottone libero di muoversi.",
    come:["Chiudi il capo e segna con uno spillo il punto di ogni asola sul bordo opposto.","Infila un filo doppio nell'ago e fai un nodo in fondo.","Cuci il bottone con 5 o 6 passaggi, appoggiando uno stuzzicadenti sopra per lasciare un po' di gambo.","Gira il filo intorno al gambo e fissa con un nodo sul rovescio."],
    yt:"cucire bottoni lavoro a maglia tutorial"},
  elastico:{n:"Cucire l'elastico",liv:"Facile",
    uso:"Per la vita di gonne e pantaloni: l'elastico resta dentro al bordo.",
    asp:"Il bordo resta morbido e regolabile.",
    come:["Piega il bordo della vita verso l'interno, sul rovescio.","Cuci il bordo con il sopraggitto, tutto intorno, lasciando un'apertura di 3 cm.","Infila l'elastico con una spilla da balia e regolalo sulla vita.","Cuci insieme le due estremità dell'elastico, poi chiudi l'apertura."],
    yt:"elastico in vita lavoro a maglia tutorial"},
  imbottire:{n:"Imbottire e chiudere",liv:"Facile",
    uso:"Per peluche, decorazioni e cuscini: riempi il lavoro e chiudi l'apertura.",
    asp:"Il lavoro prende forma, senza vuoti.",
    come:["Chiudi quasi tutto il contorno, lasciando un'apertura.","Riempi con fibra sintetica, a piccole manciate, partendo dalle zone strette.","Chiudi l'apertura con il punto materasso o il sopraggitto."],
    yt:"imbottire pupazzo a maglia tutorial"},
  fili:{n:"Nascondere i fili",liv:"Facile",
    uso:"L'ultimo passaggio di ogni lavoro: tutti i capi di filo rimasti vanno nascosti.",
    asp:"I fili non si vedono e non si sfilano.",
    come:["Sul rovescio, infila il capo del filo in un ago da lana.","Passa l'ago sotto i punti per 5 o 6 cm, seguendo il verso delle maglie.","Torna indietro per 2 cm nella direzione opposta, così il filo non scappa.","Taglia il filo in eccesso, senza tirarlo."],
    yt:"nascondere i fili lavoro a maglia tutorial"},
  bloccaggio:{n:"Bloccaggio",liv:"Facile",
    uso:"Per dare forma e misure al lavoro finito: utile per scialli, coperte e pizzi.",
    asp:"Le maglie si distendono e i bordi restano piatti.",
    come:["Bagna il lavoro in acqua tiepida, come indica l'etichetta del filato, e premi senza strizzare.","Avvolgilo in un asciugamano per togliere l'acqua in eccesso.","Stendilo in piano su una superficie morbida, dagli le misure volute e fissalo con gli spilli.","Lascia asciugare completamente prima di spostarlo."],
    yt:"bloccaggio lavoro a maglia tutorial"}
};
var J=function(k,t,d,tipi,se){return {k:k,t:t,d:d,tipi:tipi,se:se}};
var J_FILI=J("fili","Rifinire","Nascondi i fili e dai forma al lavoro.",["fili","bloccaggio"]);
var J_SPALLE=J("spalle","Spalle","Unisci il dietro al davanti sulle spalle.",["tre_ferri","tessitura","indietro"]);
var J_MANICHE=J("maniche","Maniche","Cuci le maniche al giromanica.",["giromanica","materasso","indietro"]);
var J_FIANCHI=J("fianchi","Fianchi e sotto le maniche","Chiudi i lati del corpo e le maniche, dal fondo verso l'alto.",["materasso","indietro","sopraggitto"]);
var J_COLLO=J("collo","Collo","Riprendi le maglie intorno allo scollo e lavora il bordo.",["riprendi"]);
var J_CAPP=J("cappuccio","Cappuccio","Cuci il cappuccio allo scollo, poi chiudi la sommità.",["materasso","tre_ferri","tessitura"],"cappuccio");
var J_BOTT=J("bottoni","Bottoni","Cuci i bottoni di fronte alle asole.",["bottoni"]);
var J_BORDO=J("bordo","Bordo","Riprendi le maglie intorno al lavoro e lavora il bordo.",["riprendi"]);
var J_VITA=J("vita","Cintura in vita","Piega il bordo in vita e cuci, lasciando un'apertura per infilare l'elastico.",["elastico"]);
var J_ANELLO=J("anello","Chiusura ad anello","Chiudi le due estremità tra loro per ottenere un anello.",["tessitura","materasso","tre_ferri"]);
var J_MANO=[J("lato","Lato della mano","Se hai lavorato a pezzi, chiudi il lato della mano e delle dita.",["materasso","sopraggitto"]),J("pollice","Pollice","Chiudi il pollice e uniscilo alla mano.",["materasso","sopraggitto"]),J_FILI];
var J_CALZA=[J("punta","Chiusura della punta","Chiudi le maglie della punta senza ingrossare.",["tessitura","tre_ferri"]),J("lato","Lato del piede","Solo se hai lavorato a pezzi: chiudi il lato.",["materasso"]),J_FILI];
var J_CAPPELLO=[J("lato","Lato del cappello","Se hai lavorato il cappello a pezzi, chiudi il lato.",["materasso"]),J("cima","Sommità","Chiudi la cima del cappello.",["cima","tessitura"]),J_FILI];
var J_TUBO=[J("cerchio","Chiusura a cerchio","Chiudi il lavoro a cerchio unendo le due estremità. Salta il passaggio se hai lavorato in tondo.",["tessitura","materasso","tre_ferri"]),J_FILI];
var J_COP=[J("quadrati","Unire i quadrati","Unisci quadrati o strisce: prima in file, poi le file tra loro.",["materasso","sopraggitto","tre_ferri"]),J_BORDO,J("fili","Rifinire","Nascondi i fili e dai forma al lavoro.",["bloccaggio","fili"])];
var JOIN={
  "Maglione":[J_SPALLE,J_MANICHE,J_FIANCHI,J_COLLO,J_CAPP,J_FILI],
  "Cardigan":[J_SPALLE,J_MANICHE,J_FIANCHI,J("bordo","Bordo del davanti","Riprendi le maglie sui bordi dei davanti e lavora il bordo con le asole.",["riprendi"]),J_COLLO,J_CAPP,J_BOTT,J_FILI],
  "Gilet":[J_SPALLE,J_FIANCHI,J("giro","Giromanica e scollo","Riprendi le maglie lungo giromanica e scollo e lavora il bordo.",["riprendi"]),J_FILI],
  "Top e canotta":[J("spalle","Spalline","Unisci il dietro al davanti sulle spalline.",["tre_ferri","tessitura","indietro"]),J_FIANCHI,J_FILI],
  "Vestito":[J_SPALLE,J_MANICHE,J_FIANCHI,J_COLLO,J_FILI],
  "Gonna":[J("lato","Chiusura laterale","Se hai lavorato la gonna a pezzi, chiudi il lato.",["materasso","sopraggitto"]),J_VITA,J_FILI],
  "Pantaloni":[J("gambe","Interno delle gambe","Chiudi l'interno di ogni gamba, dal fondo verso l'alto.",["materasso","indietro"]),J("cavallo","Cavallo","Unisci le due gambe tra loro, davanti e dietro.",["indietro","materasso"]),J_VITA,J_FILI],
  "Poncho e mantella":[J("lati","Lati","Unisci davanti e dietro sui lati, lasciando le aperture per le braccia.",["materasso","sopraggitto"]),J_COLLO,J_FILI],
  "Sciarpa":[J("anello","Chiusura ad anello (facoltativa)","Solo se la vuoi ad anello: chiudi le due estremità tra loro.",["tessitura","tre_ferri","materasso"]),J_FILI],
  "Stola":[J_FILI],
  "Scialle":[J("fili","Rifinire","Nascondi i fili e blocca lo scialle per aprire i punti.",["bloccaggio","fili"])],
  "Scaldacollo":J_TUBO,"Scaldamuscoli":J_TUBO,
  "Cappello":J_CAPPELLO,"Cappellino neonato":J_CAPPELLO,
  "Fascia per capelli":[J_ANELLO,J_FILI],
  "Guanti":J_MANO,"Mezzeguanti":J_MANO,"Muffole":J_MANO,
  "Calze":J_CALZA,"Calzettoni":J_CALZA,
  "Pantofole":[J("suola","Suola e tomaia","Unisci la suola alla tomaia, tutto intorno.",["sopraggitto","indietro"]),J("tallone","Tallone","Chiudi la cucitura dietro.",["materasso"]),J_FILI],
  "Scarpine neonato":[J("suola","Suola e tomaia","Unisci la suola alla tomaia, tutto intorno.",["sopraggitto","indietro"]),J("tallone","Tallone","Chiudi la cucitura dietro.",["materasso"]),J_FILI],
  "Borsa":[J("lati","Fronte e retro","Unisci fronte e retro sui tre lati.",["sopraggitto","indietro"]),J("manici","Manici","Cuci i manici con punti robusti.",["indietro"]),J_FILI],
  "Coperta":J_COP,"Plaid":J_COP,
  "Copertina neonato":[J_BORDO,J_FILI],
  "Copricuscino":[J("lati","Chiusura dei lati","Cuci i lati, lasciando l'apertura per il cuscino.",["sopraggitto","materasso"]),J_BOTT,J_FILI],
  "Cestino":[J("fondo","Fondo e lato","Cuci il fondo al lato.",["sopraggitto"]),J_FILI],
  "Presine":[J("strati","Unire gli strati","Cuci i due strati lungo il bordo.",["sopraggitto"]),J_FILI],
  "Strofinaccio":[J_FILI],
  "Tutina e body":[J_SPALLE,J_MANICHE,J_FIANCHI,J("cavallo","Cavallo","Unisci davanti e dietro tra le gambe.",["indietro","materasso"]),J_BOTT,J_FILI],
  "Giacchino neonato":[J_SPALLE,J_MANICHE,J_FIANCHI,J_COLLO,J_BOTT,J_FILI],
  "Peluche":[J("pezzi","Unire i pezzi","Cuci testa, braccia, gambe e orecchie al corpo.",["sopraggitto","materasso"]),J("imbotti","Imbottire e chiudere","Riempi con fibra e chiudi l'apertura.",["imbottire"]),J_FILI],
  "Fiori e decorazioni":[J("assembla","Assemblare","Unisci i petali e il centro.",["sopraggitto"]),J_FILI],
  "Decorazioni natalizie":[J("lati","Unire i lati","Cuci i due pezzi lungo il contorno.",["sopraggitto"]),J("imbotti","Imbottire e chiudere","Riempi con fibra e chiudi l'apertura.",["imbottire"]),J_FILI],
  "Altro":[J("unione","Unire i pezzi","Unisci i pezzi del lavoro.",["materasso","sopraggitto","tre_ferri"]),J_FILI]
};
function seamSteps(p){
  var hood=(p.parti||[]).some(function(t){return /cappuccio/i.test(t.nome)});
  return (JOIN[p.categoria]||JOIN["Altro"]).filter(function(s){return !s.se||(s.se==="cappuccio"&&hood)});
}
function drawSeams(p){
  var box=$("#seamList");if(!box)return;
  var st=seamSteps(p),c=p.cuci||{};
  var done=st.filter(function(s){return c[s.k]&&c[s.k].ok}).length;
  $("#seamIntro").textContent="Passaggi di cucitura per "+p.categoria.toLowerCase()+", nell'ordine consigliato. Scegli il punto per ogni passaggio e segna quelli fatti: "+done+" su "+st.length+".";
  box.innerHTML=st.map(function(s){
    var e=c[s.k]||{},sel=s.tipi.indexOf(e.tipo)>-1?e.tipo:s.tipi[0],sm=SEAMS[sel];
    return '<article class="seam'+(e.ok?" done":"")+'">'+
      '<div class="seam-top"><label><input type="checkbox" data-ok="'+s.k+'"'+(e.ok?" checked":"")+'><span class="st"><b>'+esc(s.t)+"</b><small>"+esc(s.d)+"</small></span></label></div>"+
      '<div class="chips" style="margin:0">'+s.tipi.map(function(t,i){
        return '<button type="button" class="chip" data-k="'+s.k+'" data-tipo="'+t+'" aria-pressed="'+(t===sel)+'">'+esc(SEAMS[t].n)+(i===0?" · consigliato":"")+"</button>";
      }).join("")+"</div>"+
      '<div class="how"><h4>'+esc(sm.n)+" · "+esc(sm.liv)+"</h4><p>"+esc(sm.uso)+"</p><ol>"+sm.come.map(function(x){return "<li>"+esc(x)+"</li>"}).join("")+"</ol><p>Aspetto: "+esc(sm.asp)+'</p><a class="yt" href="'+YT(sm.yt)+'" target="_blank" rel="noopener noreferrer">Guarda il tutorial su YouTube</a></div>'+
      "</article>";
  }).join("");
}

/* ---------- Dettaglio lavoro ---------- */
function showDetail(p){
  current={name:"lavoro",id:p.id};
  var cats=catOptions(p.categoria);
  var stati=Object.keys(STATI).map(function(k){return '<option value="'+k+'"'+(k===p.stato?" selected":"")+">"+STATI[k]+"</option>"}).join("");
  view.innerHTML=
  '<a class="back" href="#progetti">← Tutti i lavori</a>'+
  '<div class="titlerow"><input type="text" id="dNome" maxlength="80" value="'+esc(p.nome)+'" aria-label="Nome del lavoro" placeholder="Nome del lavoro"><select id="dStato" aria-label="Stato del lavoro">'+stati+'</select><button type="button" class="iconbtn" id="bTrash" aria-label="Elimina questo lavoro">'+TRASH+'<span class="lbl">Elimina?</span></button></div>'+
  '<section class="panel" aria-label="Disegno del lavoro">'+
    '<div class="gfxhead"><h3>Il tuo lavoro</h3><label class="colorpick" for="dCol"><span>Colore del filato</span><input type="color" id="dCol" value="'+colorOf(p)+'"></label></div>'+
    '<div class="chips" id="gfxTabs" style="margin:0"><button type="button" class="chip" data-t="finale" aria-pressed="true">Risultato finale</button><button type="button" class="chip" data-t="avanz" aria-pressed="false">A che punto sono</button></div>'+
    '<div class="gfxbox" id="gfxSvg"></div><p class="note" id="gfxCap"></p>'+
  "</section>"+
  '<section class="panel" aria-label="Parti del lavoro"><h3>Parti del lavoro</h3>'+
    '<div class="partlist" id="partList"></div>'+
    '<div class="partedit" id="partEdit" hidden><input type="text" id="dParte" maxlength="40" aria-label="Nome della parte"><button type="button" class="iconbtn" id="bPartDel" aria-label="Elimina questa parte">'+TRASH+'<span class="lbl">Elimina?</span></button><button type="button" class="btn" id="bFatta"></button><label class="f" style="grid-column:1/-1"><span>Istruzioni di questa parte</span><textarea id="dIstr" rows="6" placeholder="Come si lavora questa parte: maglie da avviare, punti, aumenti, diminuzioni"></textarea></label></div>'+
    '<div id="partSuggest"></div>'+
    '<form class="searchrow" id="fPart"><input type="text" id="iPart" maxlength="40" placeholder="Altra parte, es. Tasca" aria-label="Nome della nuova parte" autocomplete="off"><button class="btn" type="submit">Aggiungi</button></form>'+
  "</section>"+
  '<section class="counter" aria-label="Contarighe">'+
    '<p class="eyebrow" id="cLabel"></p>'+
    '<div class="big" id="cNum" aria-live="polite">0</div>'+
    '<p class="of" id="cOf"></p><div id="cProg"></div><div class="rep" id="cRep"></div>'+
    '<div class="ctrl"><button class="btn" id="bDec" type="button" aria-label="Togli uno">−1</button><button class="btn" id="bInc" type="button" aria-label="Aggiungi uno">+1</button></div>'+
    '<form class="setrow" id="fRiga"><label class="f" style="color:var(--panel-ink)"><span id="lSet"></span><input type="text" inputmode="numeric" pattern="[0-9]*" id="iRiga" maxlength="5" placeholder="Scrivi il numero"></label><button class="btn" id="bSet" type="submit">Imposta</button></form>'+
    '<div class="ctrl2"><button class="linkbtn" id="bUndo" type="button">Annulla l\'ultimo</button><button class="linkbtn" id="bReset" type="button">Azzera il contatore</button></div>'+
    '<label class="wake" id="wakeLbl"><input type="checkbox" id="wake"> Schermo sempre acceso</label>'+
  "</section>"+
  '<section class="counter stitch" aria-label="Contamaglie">'+
    '<div class="stitch-head"><p class="eyebrow" id="sLabel"></p><div class="sbig" id="sNum" aria-live="polite">0</div><p class="of" id="sOf"></p></div>'+
    '<div id="sProg"></div>'+
    '<div class="sctrl"><button class="btn" id="sDec" type="button" aria-label="Togli una maglia">−1</button><button class="btn" id="sInc" type="button" aria-label="Aggiungi una maglia">+1 maglia</button><button class="btn" id="sInc5" type="button" aria-label="Aggiungi cinque maglie">+5</button></div>'+
    '<button class="btn" id="sDone" type="button" style="background:transparent;color:var(--panel-ink);border:1.5px solid var(--panel-line)"></button>'+
    '<label class="autolbl wake" style="color:var(--panel-ink)"><input type="checkbox" id="sAuto"><span id="sAutoTxt"></span></label>'+
    '<p class="note" id="sTot" style="color:var(--panel-ink);opacity:.85"></p>'+
    '<div class="sadj"><button class="btn" id="sAum" type="button" style="background:transparent;color:var(--panel-ink);border:1.5px solid var(--panel-line)">Ho fatto un aumento</button><button class="btn" id="sDim" type="button" style="background:transparent;color:var(--panel-ink);border:1.5px solid var(--panel-line)">Ho fatto una diminuzione</button></div>'+
  "</section>"+
  '<section class="panel"><h3>Scheda del lavoro</h3><div class="grid">'+
    '<label class="f"><span id="lRiga"></span><input type="number" inputmode="numeric" min="0" id="dRiga" value="'+p.riga+'"></label>'+
    '<label class="f"><span id="lTot"></span><input type="number" inputmode="numeric" min="0" id="dTot" value="'+(p.totale||"")+'" placeholder="Non impostato"></label>'+
    '<label class="f"><span id="lRip"></span><input type="number" inputmode="numeric" min="0" id="dRip" value="'+(p.rip||"")+'" placeholder="Nessuna ripetizione"></label>'+
    '<label class="f"><span id="lMag"></span><input type="number" inputmode="numeric" min="0" id="dMag" value="'+(p.maglie||"")+'" placeholder="Non impostato"></label>'+
    '<label class="f"><span>Lavorazione</span><select id="dUni"><option value="ferri"'+(p.unita==="ferri"?" selected":"")+'>Ferri dritti</option><option value="giri"'+(p.unita==="giri"?" selected":"")+'>In tondo (giri)</option></select></label>'+
    '<label class="f"><span>Che cos\'è</span><select id="dCat">'+cats+"</select></label>"+
    '<label class="f"><span>Ferri (mm)</span><input type="text" inputmode="decimal" id="dFer" maxlength="6" value="'+esc(p.ferri)+'"></label>'+
    '<label class="f" style="grid-column:1/-1"><span>Filato</span><input type="text" id="dFil" maxlength="80" value="'+esc(p.filato)+'" placeholder="Marca, colore, lotto"></label>'+
  "</div></section>"+
  '<section class="panel" aria-label="Cucitura"><h3>Cucitura</h3><p class="note" id="seamIntro"></p><div class="partlist" id="seamList"></div></section>'+
  '<section class="panel" aria-label="Foto e PDF"><h3>Foto e PDF del lavoro</h3>'+
    '<p class="note">Aggiungi le foto del lavoro, poi crea un PDF da conservare: copertina, scheda, schemi, procedura parte per parte, cucitura e foto.</p>'+
    '<div class="photos" id="photoGrid"></div>'+
    '<input type="file" id="phIn" accept="image/*" multiple class="vh" tabindex="-1" aria-hidden="true">'+
    '<div style="display:flex;gap:10px;flex-wrap:wrap"><button type="button" class="btn" id="bPhoto">Aggiungi foto</button><button type="button" class="btn primary" id="bPdf">Crea il PDF</button></div>'+
    '<p class="note" id="phNote" aria-live="polite"></p>'+
  "</section>"+
  '<section class="panel"><h3>Tutorial su YouTube</h3>'+
    '<p class="note">Ogni collegamento apre in una nuova scheda i video che YouTube trova per quella tecnica.</p>'+
    '<div class="links" id="tutLinks"></div>'+
    '<div><p class="eyebrow" style="margin-bottom:5px">Cerca un\'altra tecnica</p><div class="searchrow"><input type="text" id="tSearch" maxlength="80" placeholder="Es. raglan dall\'alto, treccia" aria-label="Tecnica da cercare" autocomplete="off"><a class="btn" id="tGo" target="_blank" rel="noopener noreferrer" href="'+YT("ai ferri tutorial")+'">Cerca</a></div></div>'+
  "</section>"+
  '<section class="panel"><h3>Note</h3><textarea id="dNote" rows="6" placeholder="Modifiche al modello, misure, appunti sul campione…">'+esc(p.note)+"</textarea></section>"+
  '';

  function on(id,fn,ev){$("#"+id).addEventListener(ev||"input",fn)}
  on("dNome",function(e){p.nome=e.target.value;persist(p)});
  on("dStato",function(e){p.stato=e.target.value;persist(p)},"change");
  on("dRiga",function(e){var t=T(p);t.riga=toInt(e.target.value);t.mlav=0;refreshCounter(p,true);persist(p)});
  on("dMag",function(e){var t=T(p);t.maglie=toInt(e.target.value);if(t.maglie>0&&t.mlav>t.maglie)t.mlav=t.maglie;refreshCounter(p,true);persist(p)});
  on("dTot",function(e){T(p).totale=toInt(e.target.value);refreshCounter(p,true);persist(p)});
  on("dRip",function(e){T(p).rip=toInt(e.target.value);refreshCounter(p,true);persist(p)});
  on("dCol",function(e){p.colore=e.target.value;persist(p);drawGfx(p)});
  setupPhotos(p);
  document.querySelectorAll("#gfxTabs .chip").forEach(function(b){b.addEventListener("click",function(){gfxTab=b.getAttribute("data-t");drawGfx(p)})});
  $("#partList").addEventListener("click",function(e){
    var b=e.target.closest("[data-part]");if(!b)return;
    p.parteAttiva=b.getAttribute("data-part");hist=[];refreshCounter(p,false);
  });
  $("#partSuggest").addEventListener("click",function(e){
    var b=e.target.closest("button");if(!b)return;
    if(b.hasAttribute("data-all")){
      var have=(p.parti||[]).map(function(x){return x.nome.toLowerCase()});
      addParts(p,(PARTI_SUGG[p.categoria]||["Parte 1","Parte 2"]).filter(function(n){return have.indexOf(n.toLowerCase())<0}));
    }else if(b.hasAttribute("data-add"))addParts(p,[b.getAttribute("data-add")]);
  });
  $("#fPart").addEventListener("submit",function(e){
    e.preventDefault();
    var n=$("#iPart").value.trim();if(!n){toast("Scrivi il nome della parte");return}
    addParts(p,[n]);$("#iPart").value="";
  });
  on("dParte",function(e){var t=T(p);if(t===p)return;t.nome=e.target.value||"Parte";persist(p);refreshParts(p);drawGfx(p);var c=$("#cLabel");if(c)c.textContent=t.nome+" · "+U(p).S+" attuale"});
  on("dIstr",function(e){var t=T(p);if(t===p)return;t.istr=e.target.value;persist(p)});
  on("bFatta",function(){var t=T(p);if(t===p)return;t.fatta=!t.fatta;persist(p);refreshCounter(p,true);toast(t.fatta?"Parte segnata come finita":"Parte riaperta")},"click");
  var pd=null;
  on("bPartDel",function(){
    var b=$("#bPartDel");
    if(pd){
      clearTimeout(pd);pd=null;
      var t=T(p);p.parti=(p.parti||[]).filter(function(x){return x.id!==t.id});
      p.parteAttiva=p.parti.length?p.parti[0].id:null;hist=[];
      persist(p);refreshCounter(p,false);toast("Parte eliminata");return;
    }
    b.classList.add("armed");b.setAttribute("aria-label","Conferma: elimina questa parte");
    pd=setTimeout(function(){pd=null;b.classList.remove("armed");b.setAttribute("aria-label","Elimina questa parte")},4000);
  },"click");
  on("dUni",function(e){p.unita=e.target.value;refreshCounter(p,true);persist(p)},"change");
  on("dCat",function(e){p.categoria=e.target.value;persist(p);drawTut(p);refreshCounter(p,true)},"change");
  $("#seamList").addEventListener("click",function(e){
    var b=e.target.closest("[data-tipo]");if(!b)return;
    var k=b.getAttribute("data-k");p.cuci=p.cuci||{};
    p.cuci[k]=Object.assign({},p.cuci[k],{tipo:b.getAttribute("data-tipo")});
    persist(p);drawSeams(p);
    var nb=$('#seamList [data-k="'+k+'"][data-tipo="'+b.getAttribute("data-tipo")+'"]');if(nb)nb.focus();
  });
  $("#seamList").addEventListener("change",function(e){
    var c=e.target.closest("[data-ok]");if(!c)return;
    var k=c.getAttribute("data-ok");p.cuci=p.cuci||{};
    p.cuci[k]=Object.assign({},p.cuci[k],{ok:c.checked});
    persist(p);drawSeams(p);
    var nc=$('#seamList [data-ok="'+k+'"]');if(nc)nc.focus();
  });
  on("tSearch",function(e){var q=e.target.value.trim();$("#tGo").href=YT((q||"")+" ai ferri tutorial")});
  on("dFer",function(e){p.ferri=e.target.value.trim();persist(p)});
  on("dFil",function(e){p.filato=e.target.value;persist(p)});
  on("dNote",function(e){p.note=e.target.value;persist(p)});
  hist=[];
  on("bInc",function(){chg(p,function(t){t.riga=Math.min(99999,t.riga+1);t.mlav=0})},"click");
  on("bDec",function(){chg(p,function(t){t.riga=Math.max(0,t.riga-1);t.mlav=0})},"click");
  on("sInc",function(){stitchAdd(p,1)},"click");
  on("sInc5",function(){stitchAdd(p,5)},"click");
  on("sDec",function(){chg(p,function(t){t.mlav=Math.max(0,t.mlav-1)})},"click");
  on("sDone",function(){chg(p,function(t){t.riga=Math.min(99999,t.riga+1);t.mlav=0})},"click");
  on("sAuto",function(e){T(p).auto=e.target.checked;persist(p);refreshCounter(p,true)},"change");
  on("sAum",function(){chg(p,function(t){t.maglie=Math.min(99999,(t.maglie||0)+1)})},"click");
  on("sDim",function(){chg(p,function(t){t.maglie=Math.max(0,(t.maglie||0)-1);if(t.mlav>t.maglie)t.mlav=t.maglie})},"click");
  $("#fRiga").addEventListener("submit",function(e){
    e.preventDefault();
    var raw=$("#iRiga").value.trim();
    if(!/^\d{1,5}$/.test(raw)){toast("Scrivi un numero intero, ad esempio 42");return}
    var n=parseInt(raw,10);
    if(n===T(p).riga){toast("Il contatore è già a "+n);return}
    chg(p,function(t){t.riga=n;t.mlav=0});
    $("#iRiga").value="";$("#iRiga").blur();
    toast(U(p).S+" impostato a "+n);
  });
  on("bUndo",function(){
    var h=hist.pop();if(!h){toast("Niente da annullare");return}
    var tt=(p.parti||[]).find(function(x){return x.id===h.id})||(h.id===p.id?p:null);
    if(!tt){toast("Quella parte non c'è più");return}
    tt.riga=h.riga;tt.mlav=h.mlav;tt.maglie=h.maglie;
    if(tt!==p)p.parteAttiva=tt.id;
    refreshCounter(p,false);persist(p);toast("Annullato");
  },"click");

  var rs=null;
  on("bReset",function(){
    var b=$("#bReset");
    if(rs){clearTimeout(rs);rs=null;chg(p,function(t){t.riga=0;t.mlav=0});b.textContent="Azzera il contatore";return}
    b.textContent="Tocca ancora per azzerare";
    rs=setTimeout(function(){rs=null;b.textContent="Azzera il contatore"},4000);
  },"click");

  var ds=null;
  on("bTrash",function(){
    var b=$("#bTrash");
    if(ds){clearTimeout(ds);removeProject(p.id);return}
    b.classList.add("armed");b.setAttribute("aria-label","Conferma: elimina questo lavoro");
    ds=setTimeout(function(){ds=null;b.classList.remove("armed");b.setAttribute("aria-label","Elimina questo lavoro")},4000);
  },"click");

  if(!("wakeLock" in navigator))$("#wakeLbl").hidden=true;
  on("wake",function(e){wakeOn=e.target.checked;if(wakeOn)acquireWake();else{try{if(wake)wake.release()}catch(x){}wake=null}},"change");

  refreshCounter(p,false);
  drawTut(p);
}
var YT=function(q){return "https://www.youtube.com/results?search_query="+encodeURIComponent(q.trim())};
var TUT_BASE=[
  ["Avviare le maglie","come avviare le maglie ai ferri tutorial"],
  ["Chiudere le maglie","come chiudere le maglie ai ferri tutorial"],
  ["Rasato e legaccio","punto rasato e punto legaccio ai ferri tutorial"],
  ["Aumenti e diminuzioni","aumenti e diminuzioni ai ferri tutorial"]
];
var TUT_CAT={
  Maglione:[["Maglione dall'alto con raglan","maglione dall'alto raglan ai ferri tutorial"],["Avvio elastico","avvio elastico ai ferri tutorial"],["Cucire le maniche","cucire le maniche di un maglione ai ferri"]],
  Cardigan:[["Asole e bottoni","asole ai ferri tutorial cardigan"],["Bordo del davanti","bordo davanti cardigan ai ferri tutorial"],["Cucire le maniche","cucire le maniche di un maglione ai ferri"]],
  Sciarpa:[["Sciarpa a coste","sciarpa a coste ai ferri tutorial"],["Bordi che non si arricciano","bordo che non si arriccia ai ferri tutorial"]],
  Cappello:[["Cappello in tondo","cappello ai ferri circolari tutorial"],["Diminuzioni della cima","diminuzioni cima cappello ai ferri tutorial"],["Coste 2/2","coste 2/2 ai ferri tutorial"]],
  Calze:[["Calze a doppia punta","calze ai ferri a doppia punta tutorial"],["Il tallone","tallone calze ai ferri tutorial"],["La punta","punta calze ai ferri tutorial"]],
  Guanti:[["Guanti ai ferri","guanti ai ferri tutorial"],["Il pollice","pollice guanti ai ferri tutorial"]],
  Scialle:[["Scialle triangolare","scialle triangolare ai ferri tutorial"],["Gettati e pizzo","punti a giorno gettati ai ferri tutorial"]],
  Coperta:[["Coperta ai ferri","coperta ai ferri tutorial"],["Bordi per la coperta","bordo coperta ai ferri tutorial"],["Unire i quadrati","unire quadrati ai ferri tutorial"]]
};
Object.assign(TUT_CAT,{
  "Gilet":[["Gilet ai ferri","gilet ai ferri tutorial"],["Il giromanica","giromanica ai ferri tutorial"]],
  "Top e canotta":[["Top estivo","top estivo ai ferri tutorial"],["Canotta ai ferri","canotta ai ferri tutorial"]],
  "Vestito":[["Vestito ai ferri","vestito ai ferri tutorial"],["Diminuzioni in vita","diminuzioni in vita ai ferri tutorial"]],
  "Gonna":[["Gonna ai ferri","gonna ai ferri tutorial"],["Elastico in vita","elastico in vita ai ferri tutorial"]],
  "Pantaloni":[["Pantaloni ai ferri","pantaloni ai ferri tutorial"],["Pantaloni per neonati","pantaloncini neonato ai ferri tutorial"]],
  "Poncho e mantella":[["Poncho ai ferri","poncho ai ferri tutorial"],["Mantella ai ferri","mantella ai ferri tutorial"]],
  "Stola":[["Stola ai ferri","stola ai ferri tutorial"],["Punto a trecce","trecce ai ferri tutorial"]],
  "Scaldacollo":[["Scaldacollo in tondo","scaldacollo ai ferri tutorial"],["Colletto a coste","scaldacollo a coste ai ferri circolari tutorial"]],
  "Fascia per capelli":[["Fascia per capelli","fascia per capelli ai ferri tutorial"],["Fascia con torciglione","fascia torciglione ai ferri tutorial"]],
  "Mezzeguanti":[["Mezzeguanti","mezzeguanti ai ferri tutorial"],["Il pollice","pollice guanti ai ferri tutorial"]],
  "Muffole":[["Muffole ai ferri","muffole ai ferri tutorial"],["Il pollice","pollice guanti ai ferri tutorial"]],
  "Scaldamuscoli":[["Scaldamuscoli","scaldamuscoli ai ferri tutorial"],["Coste per i polsini","coste 2/2 ai ferri tutorial"]],
  "Calzettoni":[["Calzettoni ai ferri","calzettoni ai ferri tutorial"],["Il tallone","tallone calze ai ferri tutorial"]],
  "Pantofole":[["Pantofole ai ferri","pantofole ai ferri tutorial"],["La suola","suola pantofole ai ferri tutorial"]],
  "Borsa":[["Borsa ai ferri","borsa ai ferri tutorial"],["I manici","manici borsa ai ferri tutorial"]],
  "Plaid":[["Plaid ai ferri","plaid ai ferri tutorial"],["Plaid a trecce","plaid a trecce ai ferri tutorial"]],
  "Copricuscino":[["Copricuscino ai ferri","copricuscino ai ferri tutorial"],["Chiusura con bottoni","chiusura copricuscino ai ferri tutorial"]],
  "Cestino":[["Cestino ai ferri","cestino ai ferri tutorial"]],
  "Presine":[["Presine ai ferri","presine ai ferri tutorial"]],
  "Strofinaccio":[["Strofinaccio di cotone","strofinaccio ai ferri tutorial"],["Punto spugna","punto spugna ai ferri tutorial"]],
  "Copertina neonato":[["Copertina neonato","copertina neonato ai ferri tutorial"],["Bordo a legaccio","bordo a legaccio ai ferri tutorial"]],
  "Tutina e body":[["Tutina neonato","tutina neonato ai ferri tutorial"],["Body neonato","body neonato ai ferri tutorial"]],
  "Scarpine neonato":[["Scarpine neonato","scarpine neonato ai ferri tutorial"],["Cucire le scarpine","cucire scarpine neonato ai ferri"]],
  "Cappellino neonato":[["Cappellino neonato","cappellino neonato ai ferri tutorial"]],
  "Giacchino neonato":[["Giacchino neonato","giacchino neonato ai ferri tutorial"],["Asole e bottoni","asole ai ferri tutorial"]],
  "Peluche":[["Peluche ai ferri","peluche ai ferri tutorial"],["Imbottire e cucire","imbottire pupazzo ai ferri tutorial"]],
  "Fiori e decorazioni":[["Fiori ai ferri","fiori ai ferri tutorial"],["Decorazioni ai ferri","decorazioni ai ferri tutorial"]],
  "Decorazioni natalizie":[["Decorazioni natalizie","decorazioni natalizie ai ferri tutorial"],["Calza della Befana","calza della Befana ai ferri tutorial"]]
});
function drawTut(p){
  var box=$("#tutLinks");if(!box)return;
  var list=(TUT_CAT[p.categoria]||[]).concat(TUT_BASE);
  box.innerHTML=list.map(function(t){return '<a href="'+YT(t[1])+'" target="_blank" rel="noopener noreferrer">'+esc(t[0])+"</a>"}).join("");
}
function refreshCounter(p0,skipInputs){
  if(!$("#cNum"))return;
  var p=T(p0),u=U(p0),hasParts=p!==p0,pn=hasParts?p.nome:"";
  $("#cLabel").textContent=(hasParts?pn+" · ":"")+u.S+" attuale";
  $("#cNum").textContent=p.riga;
  $("#cOf").textContent=p.totale>0?("su "+p.totale+" "+u.p+" · "+pct(p)+"%"+(p.riga>=p.totale?" · completato":"")):"Imposta i "+u.p+" totali nella scheda per vedere l'avanzamento";
  $("#cProg").innerHTML=p.totale>0?'<div class="on-panel">'+seg(p)+"</div>":"";
  var rep=$("#cRep");
  if(p.rip>0){
    var h;
    if(p.riga===0){h="<span>Ripetizione di "+p.rip+" "+u.p+": non ancora iniziata</span>"}
    else{
      var pos=((p.riga-1)%p.rip)+1,n=Math.floor((p.riga-1)/p.rip)+1,dots="";
      if(p.rip<=24){dots='<div class="dots" aria-hidden="true">';for(var i=1;i<=p.rip;i++)dots+='<i class="'+(i<=pos?"on":"")+'"></i>';dots+="</div>"}
      h="<span>Ripetizione n. "+n+" · "+u.s+" "+pos+" di "+p.rip+"</span>"+dots;
    }
    rep.innerHTML=h;
  }else rep.innerHTML="";
  $("#bDec").disabled=p.riga<=0;
  $("#lSet").textContent="Sono già al "+u.s+" numero…";
  $("#lMag").textContent="Maglie su ogni "+u.s;
  refreshStitches(p);
  var sfx=hasParts?" · "+pn:"";
  $("#lRiga").textContent=u.S+" attuale"+sfx;
  $("#lTot").textContent=u.P+" totali"+sfx;
  $("#lRip").textContent="Ripetizione ogni (n. di "+u.p+")"+sfx;
  $("#lMag").textContent="Maglie su ogni "+u.s+sfx;
  if(!skipInputs){
    [["dRiga",p.riga],["dTot",p.totale||""],["dRip",p.rip||""],["dMag",p.maglie||""]].forEach(function(f){
      var el=$("#"+f[0]);if(el&&document.activeElement!==el)el.value=f[1];
    });
  }
  refreshParts(p0);drawGfx(p0);drawSeams(p0);
}

/* ---------- Calcolatore ---------- */
var num=function(v){var n=parseFloat(String(v).replace(",","."));return isFinite(n)?n:NaN};
var fmt=function(n,d){return n.toLocaleString("it-IT",{maximumFractionDigits:d==null?1:d})};

function showCalc(){
  current={name:"calcola"};
  view.innerHTML=
  '<section class="head"><h2>Calcola</h2></section>'+
  '<section class="panel"><h3>Il tuo campione</h3>'+
    '<p class="note">Lavora un quadrato di prova di 10 × 10 cm, poi conta le maglie e i ferri. Tutti i calcoli qui sotto partono da questi numeri, che restano salvati su questo dispositivo. Puoi usare la virgola per i decimali.</p>'+
    '<div class="grid">'+
      '<label class="f"><span>Maglie in 10 cm</span><input type="text" inputmode="decimal" id="cMg" value="20"></label>'+
      '<label class="f"><span>Ferri in 10 cm</span><input type="text" inputmode="decimal" id="cFg" value="28"></label>'+
      '<label class="f"><span>Multiplo del punto</span><input type="text" inputmode="numeric" id="cMult" value="2"></label>'+
      '<label class="f"><span>Maglie di vivagno per pezzo</span><input type="text" inputmode="numeric" id="cExtra" value="2"></label>'+
    '</div><p class="note">Il multiplo serve a far tornare il motivo: 2 per coste 1/1, 4 per coste 2/2.</p>'+
  "</section>"+
  '<section class="panel"><h3>Progetto per taglia</h3>'+
    '<p class="note">Scegli il capo e la taglia: le misure sono indicative, da adulto. Modificale con le tue e il calcolo si aggiorna.</p>'+
    '<div class="grid">'+
      '<label class="f"><span>Capo</span><select id="kCapo">'+capoOptions()+'</select></label>'+
      '<label class="f"><span>Taglia</span><select id="kTaglia"></select></label>'+
    '</div>'+
    '<div class="grid" id="kFields"></div>'+
    '<div id="outK" aria-live="polite"></div>'+
  "</section>"+
  '<section class="panel"><h3>Maglie da avviare per una misura</h3>'+
    '<p class="note">Per una sciarpa, una coperta o qualsiasi pezzo rettangolare.</p>'+
    '<div class="grid">'+
      '<label class="f"><span>Larghezza voluta (cm)</span><input type="text" inputmode="decimal" id="cW" value="50"></label>'+
      '<label class="f"><span>Altezza voluta (cm)</span><input type="text" inputmode="decimal" id="cH" value="60"></label>'+
    '</div><div id="outA" aria-live="polite"></div>'+
  "</section>"+
  '<section class="panel"><h3>Distribuire aumenti o diminuzioni</h3>'+
    '<p class="note">Per allargare o stringere in modo uniforme lungo un ferro.</p>'+
    '<div class="grid">'+
      '<label class="f"><span>Maglie sul ferro</span><input type="text" inputmode="numeric" id="sM" value="100"></label>'+
      '<label class="f"><span>Cosa devi fare</span><select id="sT"><option value="dim">Diminuzioni</option><option value="aum">Aumenti</option></select></label>'+
      '<label class="f"><span>Quante</span><input type="text" inputmode="numeric" id="sN" value="12"></label>'+
    '</div><div id="outB" aria-live="polite"></div>'+
  "</section>";
  var g=loadGauge();
  ["cMg","cFg","cMult","cExtra"].forEach(function(id){if(g[id]!=null)$("#"+id).value=g[id]});
  ["cMg","cFg","cMult","cExtra"].forEach(function(id){$("#"+id).addEventListener("input",function(){saveGauge();calcMaglie();calcTaglia()})});
  ["cW","cH"].forEach(function(id){$("#"+id).addEventListener("input",calcMaglie)});
  ["sM","sT","sN"].forEach(function(id){$("#"+id).addEventListener("input",calcDistrib);$("#"+id).addEventListener("change",calcDistrib)});
  $("#kCapo").addEventListener("change",setupCapo);
  $("#kTaglia").addEventListener("change",fillMisure);
  setupCapo();calcMaglie();calcDistrib();
}
var LSG="quaderno-ferri-campione";
function loadGauge(){try{var v=JSON.parse(localStorage.getItem(LSG));return v&&typeof v==="object"?v:{}}catch(e){return{}}}
function saveGauge(){
  var v={};["cMg","cFg","cMult","cExtra"].forEach(function(id){v[id]=$("#"+id).value});
  try{localStorage.setItem(LSG,JSON.stringify(v))}catch(e){}
}

/* Misure indicative da adulto, nell'ordine dei campi. */
var CAPI={
  maglione:{taglie:["XS","S","M","L","XL"],
    campi:[["torace","Torace (cm)"],["agio","Agio sul torace (cm)"],["lung","Lunghezza del corpo (cm)"],["manica","Lunghezza della manica (cm)"],["polso","Polso finito (cm)"],["bicipite","Bicipite (cm)"],["agioM","Agio sulla manica (cm)"]],
    misure:{XS:[80,6,56,58,16,26,4],S:[86,6,58,59,17,28,4],M:[92,6,60,60,18,30,4],L:[100,6,62,61,19,32,4],XL:[108,6,64,62,20,34,4]}},
  cappello:{taglie:["Bimbo","S","M","L","XL"],
    campi:[["testa","Circonferenza della testa (cm)"],["stretto","Quanto più stretto della testa (cm)"],["alt","Altezza del cappello (cm)"]],
    misure:{Bimbo:[50,2,17],S:[54,2,20],M:[56,2,21],L:[58,2,22],XL:[60,2,23]}}
};
var TAGLIE5=["XS","S","M","L","XL"],TAGLIE_BIMBO=["Bimbo","S","M","L","XL"];
CAPI.maglione.nome="Maglione";
CAPI.cappello.nome="Cappello";
CAPI.cardigan=Object.assign({},CAPI.maglione,{nome:"Cardigan"});
CAPI.gilet={nome:"Gilet",tipo:"gilet",taglie:TAGLIE5,
  campi:[["torace","Torace (cm)"],["agio","Agio sul torace (cm)"],["lung","Lunghezza del corpo (cm)"]],
  misure:{XS:[80,6,52],S:[86,6,54],M:[92,6,56],L:[100,6,58],XL:[108,6,60]}};
CAPI.gonna={nome:"Gonna",tipo:"gonna",taglie:TAGLIE5,
  campi:[["fianchi","Fianchi (cm)"],["agio","Agio sui fianchi (cm)"],["lung","Lunghezza della gonna (cm)"]],
  misure:{XS:[88,2,55],S:[94,2,55],M:[100,2,55],L:[106,2,55],XL:[112,2,55]}};
CAPI.scaldacollo={nome:"Scaldacollo",tipo:"tubo",taglie:["Bimbo","S","M","L"],
  campi:[["giro","Circonferenza finita (cm)"],["stretto","Quanto più stretto (cm)"],["alt","Altezza (cm)"]],
  misure:{Bimbo:[50,0,20],S:[56,0,24],M:[60,0,26],L:[64,0,28]}};
CAPI.fascia={nome:"Fascia per capelli",tipo:"tubo",taglie:TAGLIE_BIMBO,
  campi:[["giro","Circonferenza della testa (cm)"],["stretto","Quanto più stretta della testa (cm)"],["alt","Larghezza della fascia (cm)"]],
  misure:{Bimbo:[50,3,8],S:[54,3,9],M:[56,3,10],L:[58,3,10],XL:[60,3,11]}};
CAPI.guanti={nome:"Guanti",tipo:"guanto",taglie:TAGLIE_BIMBO,
  campi:[["palmo","Circonferenza del palmo (cm)"],["stretto","Quanto più stretti (cm)"],["polsino","Altezza del polsino (cm)"],["lung","Lunghezza della mano (cm)"]],
  misure:{Bimbo:[14,1,4,13],S:[18,2,5,16],M:[20,2,6,17.5],L:[22,2,6,19],XL:[24,2,7,20.5]}};
CAPI.calze={nome:"Calze",tipo:"calza",taglie:["36-37","38-39","40-41","42-43","44-45"],
  campi:[["piede","Circonferenza del piede (cm)"],["stretto","Quanto più strette del piede (cm)"],["gambale","Altezza del gambale (cm)"],["lungp","Lunghezza del piede (cm)"]],
  misure:{"36-37":[21,2,15,23],"38-39":[22,2,16,24.5],"40-41":[23.5,2,17,26],"42-43":[25,2,18,27.5],"44-45":[26.5,2,19,29]}};
var CAPI_ORDINE=["maglione","cardigan","gilet","gonna","cappello","scaldacollo","fascia","guanti","calze"];
function capoOptions(){return CAPI_ORDINE.map(function(k){return '<option value="'+k+'">'+CAPI[k].nome+"</option>"}).join("")}
function setupCapo(){
  var c=CAPI[$("#kCapo").value];
  $("#kTaglia").innerHTML=c.taglie.map(function(t){return "<option>"+t+"</option>"}).join("")+'<option value="custom">Personalizzata</option>';
  $("#kTaglia").value=c.taglie[2];
  $("#kFields").innerHTML=c.campi.map(function(f){return '<label class="f"><span>'+f[1]+'</span><input type="text" inputmode="decimal" data-k="'+f[0]+'"></label>'}).join("");
  $("#kFields").querySelectorAll("input").forEach(function(i){i.addEventListener("input",function(){$("#kTaglia").value="custom";calcTaglia()})});
  fillMisure();
}
function fillMisure(){
  var c=CAPI[$("#kCapo").value],t=$("#kTaglia").value;
  if(t!=="custom"){var m=c.misure[t];$("#kFields").querySelectorAll("input").forEach(function(i,ix){i.value=m[ix]})}
  calcTaglia();
}
function kv(k){var i=$('#kFields [data-k="'+k+'"]');return i?num(i.value):NaN}
function calcTaglia(){
  var out=$("#outK"),capo=$("#kCapo").value;
  var mg=num($("#cMg").value),fg=num($("#cFg").value);
  var mult=Math.max(1,Math.round(num($("#cMult").value)||1)),extra=Math.max(0,Math.round(num($("#cExtra").value)||0));
  var rm=function(x){return Math.max(mult,Math.round(x/mult)*mult)};
  if(!(mg>0&&fg>0)){out.innerHTML='<p class="hint">Inserisci il campione qui sopra per vedere il risultato.</p>';return}
  var html;
  if(CAPI[capo].tipo){
    html=calcAltri(capo,mg,fg,rm,extra,out);
    if(html==null)return;
  }else if(capo==="maglione"||capo==="cardigan"){
    var torace=kv("torace"),agio=kv("agio"),lung=kv("lung"),man=kv("manica"),pol=kv("polso"),bic=kv("bicipite"),agioM=kv("agioM");
    if(![torace,lung,man,pol,bic].every(function(n){return n>0})||!(agio>=0)||!(agioM>=0)){out.innerHTML='<p class="hint">Completa tutte le misure per vedere il risultato.</p>';return}
    var circ=torace+agio,giro=rm(circ*mg/10),half=rm(circ/2*mg/10)+extra,rows=Math.round(lung*fg/10);
    html='<p class="eyebrow">Corpo</p><div class="stats">'+
      stat(giro,"maglie per il giro, se lavori in tondo")+
      stat(half,"maglie per davanti e per dietro, se lavori a pezzi"+(extra>0?" (con "+extra+" di vivagno)":""))+
      stat(rows,"ferri (o giri) di lunghezza")+
      stat(fmt(giro/mg*10)+" cm","circonferenza del capo finito")+"</div>";
    var pols=rm(pol*mg/10),bics=rm((bic+agioM)*mg/10),mrows=Math.round(man*fg/10),diff=bics-pols;
    html+='<p class="eyebrow" style="margin-top:4px">Manica</p><div class="stats">'+
      stat(pols,"maglie da avviare al polso")+
      stat(bics,"maglie al bicipite")+
      stat(mrows,"ferri (o giri) di lunghezza")+"</div>";
    if(diff>=2){
      var incs=Math.floor(diff/2),gap=Math.max(1,Math.floor(mrows/incs));
      html+='<p class="note">Aumenta 1 maglia per lato ogni '+gap+" ferri, per "+incs+" volte: arrivi a "+(pols+2*incs)+" maglie."+(incs>mrows?" Gli aumenti sono più numerosi dei ferri: fanne due per lato su alcuni ferri.":"")+"</p>";
    }else if(diff<0){
      html+='<p class="note">Il polso risulta più largo del bicipite: controlla le misure.</p>';
    }else{
      html+='<p class="note">La manica non si allarga: lavorala dritta.</p>';
    }
  }else{
    var testa=kv("testa"),str=kv("stretto"),alt=kv("alt");
    if(!(testa>0&&alt>0)||!(str>=0)){out.innerHTML='<p class="hint">Completa tutte le misure per vedere il risultato.</p>';return}
    var gg=rm((testa-str)*mg/10),hr=Math.round(alt*fg/10),m8=Math.max(8,Math.round(gg/8)*8);
    html='<div class="stats">'+
      stat(gg,"maglie da avviare, in tondo")+
      stat(hr,"giri di altezza")+
      stat(fmt(gg/mg*10)+" cm","circonferenza del cappello")+"</div>"+
      '<p class="note">Per chiudere la cima in 8 spicchi servono multipli di 8: con '+m8+" maglie fai "+((m8-8)/8)+" giri di diminuzioni, ognuno ne toglie 8, poi infili il filo nelle 8 maglie rimaste.</p>";
  }
  if(capo==="cardigan")html+='<p class="note">Il cardigan si apre davanti: ogni davanti ha circa la metà delle maglie del dietro, più il bordo per i bottoni.</p>';
  out.innerHTML=html;
}
function calcAltri(capo,mg,fg,rm,extra,out){
  var t=CAPI[capo].tipo;
  var bad=function(){out.innerHTML='<p class="hint">Completa tutte le misure per vedere il risultato.</p>';return null};
  var pos=function(){for(var i=0;i<arguments.length;i++)if(!(arguments[i]>0))return false;return true};
  var rr=function(cm){return Math.round(cm*fg/10)};
  if(t==="gilet"){
    var to=kv("torace"),ag=kv("agio"),lu=kv("lung");
    if(!pos(to,lu)||!(ag>=0))return bad();
    var circ=to+ag,giro=rm(circ*mg/10),half=rm(circ/2*mg/10)+extra;
    return '<div class="stats">'+
      stat(giro,"maglie per il giro, se lavori in tondo")+
      stat(half,"maglie per davanti e per dietro, se lavori a pezzi"+(extra>0?" (con "+extra+" di vivagno)":""))+
      stat(rr(lu),"ferri (o giri) di lunghezza")+
      stat(fmt(giro/mg*10)+" cm","circonferenza del capo finito")+"</div>"+
      '<p class="note">Il giromanica si forma chiudendo qualche maglia ai lati a metà altezza: segui il tuo schema.</p>';
  }
  if(t==="gonna"){
    var fi=kv("fianchi"),ag2=kv("agio"),lu2=kv("lung");
    if(!pos(fi,lu2)||!(ag2>=0))return bad();
    var g2=rm((fi+ag2)*mg/10);
    return '<div class="stats">'+
      stat(g2,"maglie da avviare, in tondo")+
      stat(rr(lu2),"giri di lunghezza")+
      stat(fmt(g2/mg*10)+" cm","circonferenza ai fianchi")+"</div>"+
      '<p class="note">Per il bordo in vita usa ferri più piccoli di uno o due numeri, oppure un elastico.</p>';
  }
  if(t==="tubo"){
    var gi=kv("giro"),st=kv("stretto"),al=kv("alt");
    if(!pos(gi,al)||!(st>=0)||!(gi-st>0))return bad();
    var g3=rm((gi-st)*mg/10);
    return '<div class="stats">'+
      stat(g3,"maglie da avviare, in tondo")+
      stat(rr(al),"giri di altezza")+
      stat(fmt(g3/mg*10)+" cm","circonferenza finita")+"</div>";
  }
  if(t==="calza"){
    var pi=kv("piede"),st2=kv("stretto"),ga=kv("gambale"),lp=kv("lungp");
    if(!pos(pi,ga,lp)||!(st2>=0)||!(pi-st2>0))return bad();
    var g4=rm((pi-st2)*mg/10);
    return '<div class="stats">'+
      stat(g4,"maglie per il giro")+
      stat(Math.round(g4/2),"maglie del tallone (metà del giro)")+
      stat(rr(ga),"giri di gambale")+
      stat(rr(Math.max(0,lp-4)),"giri di piede, fino all'inizio della punta")+"</div>"+
      '<p class="note">La punta occupa circa 4 cm. Con 4 ferri a doppia punta, sono circa '+Math.round(g4/4)+" maglie per ferro.</p>";
  }
  if(t==="guanto"){
    var pa=kv("palmo"),st3=kv("stretto"),po=kv("polsino"),lu3=kv("lung");
    if(!pos(pa,po,lu3)||!(st3>=0)||!(pa-st3>0))return bad();
    var g5=rm((pa-st3)*mg/10);
    return '<div class="stats">'+
      stat(g5,"maglie per il giro")+
      stat(rr(po),"giri di polsino")+
      stat(rr(lu3),"giri di mano, dal polso alla punta delle dita")+
      stat(Math.round(g5/4),"maglie circa per il pollice")+"</div>";
  }
  return bad();
}
function stat(big,small){return '<div class="stat"><b>'+big+"</b><small>"+small+"</small></div>"}
function calcMaglie(){
  var mg=num($("#cMg").value),fg=num($("#cFg").value),w=num($("#cW").value),h=num($("#cH").value);
  var mult=Math.max(1,Math.round(num($("#cMult").value)||1)),extra=Math.max(0,Math.round(num($("#cExtra").value)||0));
  var out=$("#outA");
  if(!(mg>0&&fg>0&&w>0&&h>0)){out.innerHTML='<p class="hint">Inserisci campione e misure per vedere il risultato.</p>';return}
  var base=Math.max(mult,Math.round(w*mg/10/mult)*mult),cast=base+extra,rows=Math.round(h*fg/10);
  out.innerHTML='<div class="stats">'+
    stat(cast,"maglie da avviare"+(extra>0?" ("+base+" + "+extra+" di vivagno)":""))+
    stat(rows,"ferri da lavorare")+
    stat(fmt(base/mg*10)+" cm","larghezza che otterrai")+
    stat(fmt(rows/fg*10)+" cm","altezza che otterrai")+"</div>";
}
function calcDistrib(){
  var M=Math.round(num($("#sM").value)),K=Math.round(num($("#sN").value)),t=$("#sT").value,out=$("#outB");
  if(!(M>0&&K>0)){out.innerHTML='<p class="hint">Inserisci le maglie e quante ne devi aumentare o diminuire.</p>';return}
  var dim=t==="dim",lines=[];
  if(dim&&2*K>M){out.innerHTML='<p class="hint">Con '+M+" maglie puoi fare al massimo "+Math.floor(M/2)+" diminuzioni su un ferro.</p>";return}
  if(!dim&&K>M){out.innerHTML='<p class="hint">Con '+M+" maglie puoi fare al massimo "+M+" aumenti su un ferro.</p>";return}
  var plain=dim?M-2*K:M,base=Math.floor(plain/K),ex=plain%K;
  [[K-ex,base],[ex,base+1]].forEach(function(g){
    if(g[0]<=0)return;
    var run=g[1]>0?g[1]+" m. a dir., ":"";
    lines.push("<li>Ripeti "+g[0]+" "+(g[0]===1?"volta":"volte")+": "+run+(dim?"2 m. insieme":"1 aumento")+"</li>");
  });
  out.innerHTML='<ol class="steps">'+lines.join("")+"</ol>"+
    '<div class="stats">'+stat(dim?M-K:M+K,"maglie a fine ferro")+"</div>"+
    '<p class="note">'+(lines.length>1?"Alterna i due gruppi lungo il ferro per un risultato regolare. ":"")+"Se parti da un lato, controlla la simmetria sul davanti e sul dietro.</p>";
}

/* ---------- Glossario ---------- */
var GLOSS=[
["m.","Maglia."],
["dir.","Diritto: maglia lavorata a diritto."],
["rov.","Rovescio: maglia lavorata a rovescio."],
["avv.","Avviare: montare le maglie sul ferro all'inizio del lavoro."],
["chiud.","Chiudere: fermare le maglie a fine lavoro."],
["aum.","Aumento: aggiungere una maglia."],
["dim.","Diminuzione: togliere una maglia."],
["2 m. ins.","Lavorare due maglie insieme: è una diminuzione di una maglia."],
["gett.","Gettato: avvolgere il filo sul ferro per creare un'asola e un piccolo buco decorativo."],
["sfil.","Sfilata: passare la maglia da un ferro all'altro senza lavorarla."],
["acc.","Accavallare: passare la maglia sfilata sopra quella lavorata."],
["Punto legaccio","Tutti i ferri a diritto. Il tessuto è rigato e non si arriccia ai bordi."],
["Punto rasato","Un ferro a diritto e uno a rovescio. Sul rovescio del lavoro compaiono le coste orizzontali."],
["Coste 1/1","Una maglia a diritto e una a rovescio alternate su ogni ferro. Tessuto elastico per polsini e bordi."],
["Coste 2/2","Due maglie a diritto e due a rovescio alternate. Più morbide e marcate delle 1/1."],
["Punto riso","Una maglia a diritto e una a rovescio alternate, invertendole a ogni ferro."],
["Campione","Quadrato di prova, di solito 10 × 10 cm, per contare quante maglie e quanti ferri servono."],
["Vivagno","Maglia di margine ai lati del lavoro."],
["Ferro","Oltre allo strumento, indica una riga di maglie lavorata in un senso."],
["Giro","Riga di maglie lavorata in tondo, con ferri circolari o a doppia punta."],
["Segnapunti","Anellino da infilare sul ferro per segnare un punto del lavoro."],
["* … *","Ripetere quanto è scritto tra gli asterischi il numero di volte indicato."]
];
var GLQ={
  "avv.":"come avviare le maglie ai ferri tutorial",
  "chiud.":"come chiudere le maglie ai ferri tutorial",
  "aum.":"aumenti ai ferri tutorial",
  "dim.":"diminuzioni ai ferri tutorial",
  "2 m. ins.":"due maglie insieme diminuzione ai ferri tutorial",
  "gett.":"gettato ai ferri tutorial",
  "sfil.":"maglia sfilata ai ferri tutorial",
  "acc.":"accavallata ai ferri tutorial",
  "Punto legaccio":"punto legaccio ai ferri tutorial",
  "Punto rasato":"punto rasato ai ferri tutorial",
  "Coste 1/1":"coste 1/1 ai ferri tutorial",
  "Coste 2/2":"coste 2/2 ai ferri tutorial",
  "Punto riso":"punto riso ai ferri tutorial",
  "Campione":"come fare il campione ai ferri tutorial",
  "Giro":"lavorare in tondo ai ferri circolari tutorial"
};
function showGlossary(){
  current={name:"glossario"};
  view.innerHTML=
  '<section class="head"><h2>Glossario</h2></section>'+
  '<label class="f" style="margin-bottom:14px"><span>Cerca una sigla o un punto</span><input type="text" id="gQ" placeholder="Es. gettato, coste, dir." autocomplete="off"></label>'+
  '<section class="panel"><dl class="gl" id="gl"></dl><p class="note" id="gEmpty" hidden>Nessun risultato.</p></section>'+
  '<p class="note">Le sigle possono cambiare da un modello all\'altro: se una non torna, controlla la legenda del tuo schema.</p>';
  function draw(){
    var q=$("#gQ").value.trim().toLowerCase();
    var rows=GLOSS.filter(function(g){return !q||g[0].toLowerCase().indexOf(q)>-1||g[1].toLowerCase().indexOf(q)>-1});
    $("#gl").innerHTML=rows.map(function(g){
      var yt=GLQ[g[0]]?'<br><a class="yt" href="'+YT(GLQ[g[0]])+'" target="_blank" rel="noopener noreferrer">Guarda i tutorial su YouTube</a>':"";
      return "<div><dt>"+esc(g[0])+"</dt><dd>"+esc(g[1])+yt+"</dd></div>";
    }).join("");
    $("#gEmpty").hidden=rows.length>0;
  }
  $("#gQ").addEventListener("input",draw);draw();
}

/* ---------- Foto ---------- */
var capCache={},blobUrl={},memPh={};
/* Fuori da Claude (sito installato): foto salvate in IndexedDB e PDF scaricato come file normale. */
var STANDALONE=!(window.claude&&window.claude.use);
var IDBP=null;
function idb(){
  if(!IDBP)IDBP=new Promise(function(res,rej){
    var r=indexedDB.open("quaderno-ferri-foto",1);
    r.onupgradeneeded=function(){r.result.createObjectStore("foto")};
    r.onsuccess=function(){res(r.result)};r.onerror=function(){rej(r.error)};
  });
  return IDBP;
}
function idbOp(mode,fn){
  return idb().then(function(db){return new Promise(function(res,rej){
    var tx=db.transaction("foto",mode),rq=fn(tx.objectStore("foto"));
    tx.oncomplete=function(){res(rq&&rq.result)};tx.onerror=function(){rej(tx.error)};
  })});
}
var localAssets={
  upload:function(blob){var id="l"+newId();return idbOp("readwrite",function(s){return s.put(blob,id)}).then(function(){return {id:id,url:"",sizeBytes:blob.size,contentType:blob.type}})},
  "delete":function(id){return idbOp("readwrite",function(s){return s["delete"](id)})},
  get:function(id){return idbOp("readonly",function(s){return s.get(id)})}
};
var fileDownloads={save:function(o){
  var u=URL.createObjectURL(o.data),a=document.createElement("a");
  a.href=u;a.download=o.filename;document.body.appendChild(a);a.click();a.remove();
  setTimeout(function(){URL.revokeObjectURL(u)},8000);
  return Promise.resolve({status:"saved"});
}};
function getCap(n){
  if(!capCache[n]){
    var pr;
    if(STANDALONE)pr=n==="assets"?(window.indexedDB?localAssets:null):n==="downloads"?fileDownloads:null;
    else{try{pr=window.claude.use(n)}catch(e){pr=null}}
    capCache[n]=Promise.resolve(pr).catch(function(){return null});
  }
  return capCache[n];
}
function photoItems(p){return (p.foto||[]).concat(memPh[p.id]||[])}
function photoSrc(it){return blobUrl[it.id]||("/_blob/"+it.id)}
function loadImg(src){
  return new Promise(function(res,rej){var im=new Image();im.onload=function(){res(im)};im.onerror=function(){rej(new Error("img"))};im.src=src});
}
function canvasJpeg(im,max,q,sw,sh){
  var w=sw||im.naturalWidth||im.width,h=sh||im.naturalHeight||im.height,s=Math.min(1,max/Math.max(w,h));
  var cw=Math.max(1,Math.round(w*s)),ch=Math.max(1,Math.round(h*s)),c=document.createElement("canvas");
  c.width=cw;c.height=ch;var g=c.getContext("2d");g.fillStyle="#fff";g.fillRect(0,0,cw,ch);g.drawImage(im,0,0,cw,ch);
  return new Promise(function(res,rej){c.toBlob(function(b){b?res({blob:b,w:cw,h:ch}):rej(new Error("jpeg"))},"image/jpeg",q)});
}
async function resizeFile(file,max){
  var u=URL.createObjectURL(file);
  try{var im=await loadImg(u);return await canvasJpeg(im,max,0.85)}finally{URL.revokeObjectURL(u)}
}
function drawPhotos(p){
  var box=$("#photoGrid");if(!box)return;
  var list=photoItems(p);
  box.innerHTML=list.map(function(it){
    var cov=p.copertina===it.id;
    return '<figure class="ph"><div class="phimg"><img alt="Foto del lavoro" src="'+esc(photoSrc(it))+'"></div>'+
      '<input type="text" class="phcap" data-cap="'+esc(it.id)+'" maxlength="120" placeholder="Didascalia" value="'+esc(it.did||"")+'" aria-label="Didascalia della foto">'+
      '<div class="phbtn"><button type="button" class="chip" data-cov="'+esc(it.id)+'" aria-pressed="'+cov+'">Copertina</button><button type="button" class="btn" data-del="'+esc(it.id)+'">Rimuovi</button></div></figure>';
  }).join("");
}
function setupPhotos(p){
  var note=$("#phNote"),grid=$("#photoGrid");
  drawPhotos(p);
  if(STANDALONE&&window.indexedDB){
    var miss=(p.foto||[]).filter(function(f){return !blobUrl[f.id]});
    if(miss.length)Promise.all(miss.map(function(f){return localAssets.get(f.id).then(function(b){if(b)blobUrl[f.id]=URL.createObjectURL(b)}).catch(function(){})})).then(function(){if($("#photoGrid"))drawPhotos(p)});
  }
  getCap("assets").then(function(as){
    if(!$("#phNote"))return;
    if(!as)$("#phNote").textContent="Qui le foto restano solo finché l'app è aperta: non si possono salvare nel lavoro. Il PDF le include comunque.";
  });
  getCap("downloads").then(function(dl){
    if(!dl&&$("#bPdf")){$("#bPdf").disabled=true;$("#phNote").textContent="Il salvataggio del PDF non è disponibile in questa vista. Aprila dalla pagina del lavoro in Claude."}
  });
  $("#bPhoto").addEventListener("click",function(){$("#phIn").click()});
  $("#phIn").addEventListener("change",async function(e){
    var files=Array.prototype.slice.call(e.target.files||[]);e.target.value="";
    if(!files.length)return;
    var as=await getCap("assets"),bad=0;
    note.textContent="Preparo le foto…";
    for(var i=0;i<files.length;i++){
      try{
        var r=await resizeFile(files[i],1600),id;
        if(as){var up=await as.upload(r.blob);id=up.id;blobUrl[id]=URL.createObjectURL(r.blob);p.foto.push({id:id,did:""})}
        else{id="m"+newId();blobUrl[id]=URL.createObjectURL(r.blob);(memPh[p.id]=memPh[p.id]||[]).push({id:id,did:"",mem:true})}
      }catch(err){bad++}
    }
    persist(p);drawPhotos(p);
    note.textContent=bad?(bad+" foto non caricate: prova con un'immagine JPG o PNG."):"";
  });
  grid.addEventListener("input",function(e){
    var id=e.target.getAttribute&&e.target.getAttribute("data-cap");if(!id)return;
    var it=photoItems(p).find(function(x){return x.id===id});if(!it)return;
    it.did=e.target.value;if(!it.mem)persist(p);
  });
  grid.addEventListener("click",function(e){
    var b=e.target.closest("button");if(!b)return;
    var cv=b.getAttribute("data-cov"),dl=b.getAttribute("data-del");
    if(cv){p.copertina=p.copertina===cv?"":cv;persist(p);drawPhotos(p);return}
    if(dl){
      if(b.getAttribute("data-armed")!=="1"){b.setAttribute("data-armed","1");b.textContent="Sicuro?";setTimeout(function(){if(b.isConnected){b.removeAttribute("data-armed");b.textContent="Rimuovi"}},3000);return}
      var mi=(memPh[p.id]||[]).findIndex(function(x){return x.id===dl});
      if(mi>-1)memPh[p.id].splice(mi,1);
      else{
        p.foto=p.foto.filter(function(x){return x.id!==dl});
        getCap("assets").then(function(as){if(as&&as.delete)as.delete(dl).catch(function(){})});
      }
      if(p.copertina===dl)p.copertina="";
      persist(p);drawPhotos(p);
    }
  });
  $("#bPdf").addEventListener("click",function(){makePdf(p)});
}

/* ---------- PDF ---------- */
var PW=595.28,PH=841.89;
var HW=[278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
var HB=[278,333,474,556,556,889,722,238,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,333,333,584,584,584,611,975,722,722,722,722,667,611,778,722,278,556,722,611,833,722,778,667,778,722,667,611,722,667,944,667,667,611,333,278,333,584,556,333,556,611,556,611,556,333,611,611,278,278,556,278,889,611,611,611,611,389,556,333,611,556,778,556,556,500,389,280,389,584];
var WIN={"à":224,"è":232,"é":233,"ì":236,"ò":242,"ù":249,"À":192,"È":200,"É":201,"Ì":204,"Ò":210,"Ù":217,"’":146,"‘":145,"“":147,"”":148,"–":150,"—":151,"•":149,"…":133,"·":183,"°":176,"×":215,"ç":231,"ñ":241,"ö":246,"ü":252,"ä":228,"â":226,"ê":234,"î":238,"ô":244,"û":251,"€":128,"½":189};
var WBASE={224:"a",226:"a",228:"a",232:"e",233:"e",234:"e",236:"i",238:"i",242:"o",244:"o",246:"o",249:"u",251:"u",252:"u",231:"c",241:"n",192:"A",200:"E",201:"E",204:"I",210:"O",217:"U"};
var WSPEC={146:[222,278],145:[222,278],147:[333,500],148:[333,500],150:[556,556],151:[1000,1000],149:[350,350],133:[1000,1000],183:[278,278],176:[400,400],215:[584,584],128:[556,556],189:[834,834]};
function wcode(ch){
  var c=ch.charCodeAt(0);
  if(c>=32&&c<127)return c;
  if(c===160||c===9||c===10||c===13)return 32;
  return WIN[ch]||63;
}
function cw1(code,b){
  if(code>=32&&code<=126)return (b?HB:HW)[code-32];
  if(WBASE[code])return (b?HB:HW)[WBASE[code].charCodeAt(0)-32];
  var s=WSPEC[code];return s?s[b?1:0]:556;
}
function tw(s,sz,b){var w=0;s=String(s);for(var i=0;i<s.length;i++)w+=cw1(wcode(s[i]),b);return w*sz/1000}
function hexTxt(s){var o="";s=String(s);for(var i=0;i<s.length;i++){var h=wcode(s[i]).toString(16);o+=h.length<2?"0"+h:h}return o}
function n2(v){return String(Math.round(v*100)/100)}
function PdfDoc(){this.pages=[];this.imgs=[];this.np()}
PdfDoc.prototype={
  np:function(){this.cur={o:[],im:{}};this.pages.push(this.cur)},
  rgb:function(c){return [1,3,5].map(function(i){return (parseInt(c.substr(i,2),16)/255).toFixed(3)}).join(" ")},
  rect:function(x,y,w,h,c){this.cur.o.push(this.rgb(c)+" rg "+n2(x)+" "+n2(PH-y-h)+" "+n2(w)+" "+n2(h)+" re f")},
  line:function(x1,y1,x2,y2,c,wd){this.cur.o.push(this.rgb(c)+" RG "+n2(wd||0.6)+" w "+n2(x1)+" "+n2(PH-y1)+" m "+n2(x2)+" "+n2(PH-y2)+" l S")},
  txt:function(x,y,s,sz,b,c,sp){
    if(!String(s).length)return;
    this.cur.o.push("BT /F"+(b?2:1)+" "+n2(sz)+" Tf "+this.rgb(c)+" rg "+n2(sp||0)+" Tc "+n2(x)+" "+n2(PH-y)+" Td <"+hexTxt(s)+"> Tj ET");
  },
  addImg:function(bytes,w,h){this.imgs.push({b:bytes,w:w,h:h});return this.imgs.length-1},
  img:function(i,x,y,w,h,clip){
    this.cur.im[i]=true;
    var by=PH-y-h;
    this.cur.o.push("q "+(clip?n2(clip[0])+" "+n2(PH-clip[1]-clip[3])+" "+n2(clip[2])+" "+n2(clip[3])+" re W n ":"")+n2(w)+" 0 0 "+n2(h)+" "+n2(x)+" "+n2(by)+" cm /Im"+i+" Do Q");
  },
  build:function(title){
    var parts=[],off=0,offs=[];
    function put(x){parts.push(x);off+=x.length}
    function obj(id,body){offs[id]=off;put(id+" 0 obj\n"+body+"\nendobj\n")}
    var nI=this.imgs.length,base=6+nI,np=this.pages.length,last=base+2*np-1;
    put("%PDF-1.4\n");
    obj(1,"<< /Type /Catalog /Pages 2 0 R >>");
    var kids=[];for(var j=0;j<np;j++)kids.push((base+2*j+1)+" 0 R");
    obj(2,"<< /Type /Pages /Count "+np+" /Kids ["+kids.join(" ")+"] >>");
    obj(3,"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
    obj(4,"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");
    var tt="FEFF";for(var k=0;k<title.length;k++){var h=title.charCodeAt(k).toString(16);tt+=("0000"+h).slice(-4)}
    obj(5,"<< /Title <"+tt+"> /Producer (Quaderno dei Ferri) >>");
    for(var i=0;i<nI;i++){
      var im=this.imgs[i];offs[6+i]=off;
      put((6+i)+" 0 obj\n<< /Type /XObject /Subtype /Image /Width "+im.w+" /Height "+im.h+" /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length "+im.b.length+" >>\nstream\n");
      put(im.b);put("\nendstream\nendobj\n");
    }
    for(var q=0;q<np;q++){
      var pg=this.pages[q],cid=base+2*q,pid=cid+1,body=pg.o.join("\n");
      obj(cid,"<< /Length "+body.length+" >>\nstream\n"+body+"\nendstream");
      var xo=Object.keys(pg.im).map(function(k2){return "/Im"+k2+" "+(6+Number(k2))+" 0 R"}).join(" ");
      obj(pid,"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 "+PW+" "+PH+"] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << "+xo+" >> >> /Contents "+cid+" 0 R >>");
    }
    var xr=off,s="xref\n0 "+(last+1)+"\n0000000000 65535 f \n";
    for(var o=1;o<=last;o++)s+=("0000000000"+offs[o]).slice(-10)+" 00000 n \n";
    s+="trailer\n<< /Size "+(last+1)+" /Root 1 0 R /Info 5 0 R >>\nstartxref\n"+xr+"\n%%EOF\n";
    put(s);
    return new Blob(parts,{type:"application/pdf"});
  }
};
var PDFCSS=".g-empty{fill:#E4E8F2;stroke:#596082;stroke-width:1.5;stroke-dasharray:5 4}.g-line{fill:none;stroke:#1B2140;stroke-opacity:.55;stroke-width:2;stroke-linejoin:round}.g-dk{fill:#000;fill-opacity:.28}.g-ln{fill:none;stroke:#000;stroke-opacity:.3;stroke-width:3;stroke-linecap:round}.g-dash{stroke-dasharray:6 6}.g-bt{fill:#000;fill-opacity:.35}.g-txt{fill:#1B2140;font:600 11px Helvetica,Arial,sans-serif}.g-txt2{fill:#596082;font:500 11px Helvetica,Arial,sans-serif}";
async function svgJpeg(svg,wpx){
  var m=/viewBox="([^"]+)"/.exec(svg),vb=m[1].split(/\s+/).map(Number),hpx=Math.round(wpx*vb[3]/vb[2]);
  svg=svg.replace("<svg ",'<svg xmlns="http://www.w3.org/2000/svg" width="'+wpx+'" height="'+hpx+'" ').replace("<defs>","<style>"+PDFCSS+"</style><defs>");
  var u=URL.createObjectURL(new Blob([svg],{type:"image/svg+xml"}));
  try{
    var im=await loadImg(u),r=await canvasJpeg(im,wpx,0.92,wpx,hpx);
    return {b:new Uint8Array(await r.blob.arrayBuffer()),w:r.w,h:r.h};
  }finally{URL.revokeObjectURL(u)}
}
async function photoJpeg(it){
  var im=await loadImg(photoSrc(it)),r=await canvasJpeg(im,1400,0.85);
  return {b:new Uint8Array(await r.blob.arrayBuffer()),w:r.w,h:r.h,did:it.did||"",id:it.id};
}
function slug(s){return String(s||"lavoro").normalize("NFD").replace(/[̀-ͯ]/g,"").replace(/[^a-zA-Z0-9]+/g,"-").replace(/^-+|-+$/g,"").toLowerCase().slice(0,50)||"lavoro"}
function pdfBuild(p,photos,shots){
  var doc=new PdfDoc(),M=48,CW=PW-2*M,y=M;
  var INK="#1B2140",INK2="#596082",ACC="#C0264F",SOFT="#EEF0F6",LINE="#CDD2E3",DARK="#0F1328";
  function wrap(s,w,sz,b){
    var out=[];
    String(s).split(/\n/).forEach(function(par){
      var words=par.split(/\s+/).filter(Boolean),line="";
      if(!words.length){out.push("");return}
      words.forEach(function(wd){
        var t=line?line+" "+wd:wd;
        if(tw(t,sz,b)<=w){line=t;return}
        if(line)out.push(line);
        while(tw(wd,sz,b)>w&&wd.length>1){var k=wd.length;while(k>1&&tw(wd.slice(0,k),sz,b)>w)k--;out.push(wd.slice(0,k));wd=wd.slice(k)}
        line=wd;
      });
      out.push(line);
    });
    return out;
  }
  function ensure(h){if(y+h>PH-M-12){doc.np();y=M}}
  function para(s,x,w,sz,b,c,lead){
    wrap(s,w,sz,b).forEach(function(l){
      if(l===""){y+=lead*0.5;return}
      ensure(lead);doc.txt(x,y+sz,l,sz,b,c);y+=lead;
    });
  }
  function heading(t){
    ensure(60);doc.rect(M,y,4,20,ACC);doc.txt(M+14,y+16,t,19,true,INK);y+=36;
  }
  function when(){var d=new Date(p.creato);return isFinite(d)?d.toLocaleDateString("it-IT",{day:"numeric",month:"long",year:"numeric"}):""}
  function imgFit(sh,x,yy,w,h){
    var s=Math.min(w/sh.w,h/sh.h),dw=sh.w*s,dh=sh.h*s,i=sh.idx!=null?sh.idx:(sh.idx=doc.addImg(sh.b,sh.w,sh.h));
    doc.img(i,x+(w-dw)/2,yy+(h-dh)/2,dw,dh);return {w:dw,h:dh};
  }
  var U0=UN[p.unita]||UN.ferri;
  /* copertina */
  var dh=PH*0.44;
  doc.rect(0,0,PW,dh,DARK);
  doc.txt(M,M+8,"QUADERNO DEI FERRI",9,true,"#F27A9D",2);
  var tl=wrap(p.nome||"Il mio lavoro",CW,34,true).slice(0,4),ty=dh-100-(tl.length-1)*40;
  tl.forEach(function(l,i){doc.txt(M,ty+34+i*40,l,34,true,"#FFFFFF")});
  doc.txt(M,dh-30,p.categoria+"  ·  "+(STATI[p.stato]||""),12,false,"#C9CEE8");
  doc.rect(M,dh,70,6,ACC);
  var by=dh+34,bh=PH-dh-34-118,cover=photos.filter(function(f){return f.id===p.copertina})[0]||photos[0];
  doc.rect(M,by,CW,bh,SOFT);
  if(cover){
    var cs=Math.max(CW/cover.w,bh/cover.h),cwid=cover.w*cs,chei=cover.h*cs,ci=doc.addImg(cover.b,cover.w,cover.h);
    doc.img(ci,M+(CW-cwid)/2,by+(bh-chei)/2,cwid,chei,[M,by,CW,bh]);
  }else imgFit(shots.sil,M+12,by+12,CW-24,bh-24);
  var pg=progress(p),facts=[["Filato",p.filato||"—"],["Ferri",p.ferri?p.ferri+" mm":"—"],["Parti",String((p.parti||[]).length||1)],["Avanzamento",pg.has?pg.pct+"%":"—"]],fw=CW/4;
  facts.forEach(function(f,i){
    var x=M+i*fw,v=wrap(f[1],fw-12,11,true)[0]||"";
    doc.txt(x,PH-M-40,f[0].toUpperCase(),7.5,true,INK2,1);doc.txt(x,PH-M-24,v,11,true,INK);
  });
  if(when())doc.txt(M,PH-M+2,"Iniziato il "+when(),8.5,false,INK2);
  /* scheda e schemi */
  doc.np();y=M;
  heading("Scheda del lavoro");
  var pairs=[["Capo",p.categoria],["Lavorazione",p.unita==="giri"?"In tondo (a giri)":"Ferri dritti"],["Filato",p.filato||"—"],["Ferri",p.ferri?p.ferri+" mm":"—"],["Stato",STATI[p.stato]||"—"],["Iniziato",when()||"—"]];
  for(var i=0;i<pairs.length;i+=2){
    var rows=[pairs[i],pairs[i+1]].filter(Boolean),hh=0;
    rows.forEach(function(r){hh=Math.max(hh,wrap(r[1],CW/2-14,11.5,true).length)});
    ensure(18+hh*15+10);
    rows.forEach(function(r,j){
      var x=M+j*(CW/2);doc.txt(x,y+8,r[0].toUpperCase(),7.5,true,INK2,1);
      wrap(r[1],CW/2-14,11.5,true).forEach(function(l,k){doc.txt(x,y+24+k*15,l,11.5,true,INK)});
    });
    y+=18+hh*15+10;
  }
  if((p.parti||[]).length){
    y+=6;ensure(60);
    doc.rect(M,y,CW,22,SOFT);
    var cx=[M+10,M+CW*0.52,M+CW*0.68,M+CW*0.86];
    ["PARTE","MAGLIE","LUNGHEZZA","RIPETIZIONE"].forEach(function(t,i){doc.txt(cx[i],y+15,t,7.5,true,INK2,1)});
    y+=22;
    p.parti.forEach(function(t){
      var u=UN[t.unita]||UN[p.unita]||UN.ferri;ensure(26);
      doc.txt(cx[0],y+17,wrap(t.nome,CW*0.48,10.5,true)[0],10.5,true,INK);
      doc.txt(cx[1],y+17,t.maglie>0?String(t.maglie):"—",10.5,false,INK);
      doc.txt(cx[2],y+17,t.totale>0?t.totale+" "+u.p:"—",10.5,false,INK);
      doc.txt(cx[3],y+17,t.rip>0?"ogni "+t.rip:"—",10.5,false,INK);
      doc.line(M,y+26,M+CW,y+26,LINE,0.5);y+=26;
    });
  }
  y+=22;heading("Schemi");
  var sw=Math.min(CW,(p.parti||[]).length?190:260),sh1=shots.sil.h*sw/shots.sil.w;
  ensure(sh1+34);
  imgFit(shots.sil,M+(CW-sw)/2,y,sw,sh1);y+=sh1+14;
  doc.txt(M,y+8,"Il lavoro finito, nel colore del filato",9,false,INK2);y+=24;
  if(shots.pcs){
    var pw=Math.min(CW,430),ph2=shots.pcs.h*pw/shots.pcs.w;
    ensure(ph2+34);imgFit(shots.pcs,M+(CW-pw)/2,y,pw,ph2);y+=ph2+14;
    doc.txt(M,y+8,"I pezzi del lavoro, con maglie e lunghezza di ciascuno",9,false,INK2);y+=24;
  }
  /* procedura */
  doc.np();y=M;heading("Procedura");
  if((p.parti||[]).length){
    para("Lavora le parti nell'ordine indicato. I numeri sono quelli della scheda del lavoro.",M,CW,10.5,false,INK2,15);y+=8;
    p.parti.forEach(function(t,i){
      var u=UN[t.unita]||UN[p.unita]||UN.ferri;
      ensure(70);
      doc.rect(M,y,24,24,ACC);
      var ns=String(i+1);doc.txt(M+12-tw(ns,11,true)/2,y+16.5,ns,11,true,"#FFFFFF");
      doc.txt(M+36,y+11,t.nome,13,true,INK);
      var meta=[t.maglie>0?t.maglie+" maglie":"",t.totale>0?t.totale+" "+u.p:"",t.rip>0?"ripetizione ogni "+t.rip:""].filter(Boolean).join("  ·  ");
      if(meta)doc.txt(M+36,y+24,meta,9.5,false,INK2);
      y+=36;
      if(t.istr&&t.istr.trim())para(t.istr,M+36,CW-36,10.5,false,INK,15);
      else para("Nessuna istruzione scritta per questa parte.",M+36,CW-36,10,false,INK2,14);
      y+=14;
    });
  }
  if(p.note&&p.note.trim()){
    y+=4;ensure(40);doc.txt(M,y+10,"NOTE DEL LAVORO",8,true,ACC,1.5);y+=20;
    para(p.note,M,CW,10.5,false,INK,15);y+=10;
  }else if(!(p.parti||[]).length){para("Nessuna istruzione scritta. Aggiungi note o dividi il lavoro in parti per vederle qui.",M,CW,10.5,false,INK2,15)}
  /* cucitura */
  var st=seamSteps(p),c=p.cuci||{};
  if(st.length&&(p.parti||[]).length!==1){
    doc.np();y=M;heading("Cucitura");
    para("I passaggi per unire il lavoro, nell'ordine consigliato, con il punto scelto.",M,CW,10.5,false,INK2,15);y+=8;
    st.forEach(function(s,i){
      var e=c[s.k]||{},sel=s.tipi.indexOf(e.tipo)>-1?e.tipo:s.tipi[0],sm=SEAMS[sel];
      ensure(110);
      doc.txt(M,y+12,(i+1)+". "+s.t+(e.ok?"  (fatto)":""),12.5,true,INK);y+=20;
      para(s.d,M,CW,10,false,INK2,14);y+=4;
      doc.txt(M,y+10,"Punto: "+sm.n+"  ·  "+sm.liv,10,true,ACC);y+=18;
      para(sm.uso,M,CW,10,false,INK,14);y+=3;
      sm.come.forEach(function(x,k){
        var ls=wrap(x,CW-26,10,false);ensure(ls.length*14);
        doc.txt(M+6,y+10,(k+1)+".",10,true,INK2);
        ls.forEach(function(l){doc.txt(M+24,y+10,l,10,false,INK);y+=14});
      });
      y+=2;para("Aspetto: "+sm.asp,M,CW,9.5,false,INK2,13);
      y+=8;doc.line(M,y,M+CW,y,LINE,0.5);y+=14;
    });
  }
  /* foto */
  if(photos.length){
    doc.np();y=M;heading("Foto del lavoro");
    var gap=14,cwid2=(CW-gap)/2,maxH=250;
    for(var a=0;a<photos.length;a+=2){
      var row=[photos[a],photos[a+1]].filter(Boolean),rh=0;
      var info=row.map(function(f){
        var s=Math.min(cwid2/f.w,maxH/f.h),iw=f.w*s,ih=f.h*s,cl=f.did?wrap(f.did,cwid2,9.5,false):[];
        rh=Math.max(rh,ih+(cl.length?cl.length*13+6:0));return {f:f,iw:iw,ih:ih,cl:cl};
      });
      ensure(rh+20);
      info.forEach(function(o,j){
        var x=M+j*(cwid2+gap),ix=x+(cwid2-o.iw)/2,ii=doc.addImg(o.f.b,o.f.w,o.f.h);
        doc.rect(x-0.5,y-0.5,cwid2+1,0.01,"#FFFFFF");
        doc.img(ii,ix,y,o.iw,o.ih);
        o.cl.forEach(function(l,k){doc.txt(x,y+o.ih+14+k*13,l,9.5,false,INK2)});
      });
      y+=rh+22;
    }
  }
  /* piè di pagina */
  var total=doc.pages.length;
  doc.pages.forEach(function(pg2,i){
    if(i===0)return;doc.cur=pg2;
    doc.line(M,PH-M+8,PW-M,PH-M+8,LINE,0.5);
    doc.txt(M,PH-M+22,(p.nome||"")+"  ·  Quaderno dei Ferri",8,false,INK2);
    var pn="pag. "+(i+1)+" di "+total;doc.txt(PW-M-tw(pn,8,false),PH-M+22,pn,8,false,INK2);
  });
  return doc.build(p.nome||"Lavoro ai ferri");
}
async function makePdf(p){
  var note=$("#phNote"),btn=$("#bPdf");
  function say(t){if($("#phNote"))$("#phNote").textContent=t}
  btn.disabled=true;say("Preparo il PDF…");
  try{
    var dl=await getCap("downloads");
    if(!dl){say("Il salvataggio del PDF non è disponibile in questa vista.");return}
    var col=colorOf(p),shots={};
    shots.sil=await svgJpeg(silSvg(p,1,col),900);
    if((p.parti||[]).length)shots.pcs=await svgJpeg(piecesSvg(p,col,true),1100);
    var photos=[],skipped=0,items=photoItems(p);
    for(var i=0;i<items.length;i++){try{photos.push(await photoJpeg(items[i]))}catch(e){skipped++}}
    var blob=pdfBuild(p,photos,shots);
    try{
      await dl.save({filename:slug(p.nome)+".pdf",data:blob});
      say("PDF pronto"+(skipped?" ("+skipped+" foto non lette e lasciate fuori)":"")+".");
    }catch(e){
      say(e&&e.code==="declined"?"Salvataggio annullato.":"Non sono riuscito a salvare il PDF. Riprova.");
    }
  }catch(e){say("Non sono riuscito a creare il PDF. Riprova.")}
  finally{if($("#bPdf"))$("#bPdf").disabled=false}
}

/* ---------- Avvio ---------- */
async function init(){
  projects=loadLocal();
  var hasClaude=!!(window.claude&&window.claude.use);
  if(!hasClaude)loaded=true;
  route();
  if(!hasClaude){setSync("local");return}
  setSync("load");
  var db=null,user=null,id=null;
  try{db=await window.claude.use("db");user=await window.claude.use("user");if(user)id=await user.id()}catch(e){}
  if(!db||!id){loaded=true;setSync("local");onDataChange();return}
  col=db.collection("data/users/"+id);
  loadTimer=setTimeout(function(){setSync("slow")},10000);
  col.onSnapshot(onSnap,onErr);
}
init();
})();

/* ---------- PWA: service worker e aggiornamento automatico ---------- */
(function(){
  if(!("serviceWorker" in navigator)||!/^https?:$/.test(location.protocol))return;
  var had=!!navigator.serviceWorker.controller,reloading=false;
  navigator.serviceWorker.addEventListener("controllerchange",function(){
    if(!had){had=true;return}
    if(reloading)return;reloading=true;
    var t=document.getElementById("toast");
    if(t){t.textContent="Nuova versione: aggiorno…";t.hidden=false}
    setTimeout(function(){location.reload()},1200);
  });
  navigator.serviceWorker.register("service-worker.js").then(function(reg){
    function check(){reg.update().catch(function(){})}
    document.addEventListener("visibilitychange",function(){if(!document.hidden)check()});
    window.addEventListener("online",check);
    setInterval(check,30*60*1000);
  }).catch(function(){});
})();
